/* ============================================================
   FLOTTE 2.0 — Alerts & Maintenance Module
   ============================================================ */

function renderAlerts() {
  const alerts = DB.alerts();
  const unresolved = alerts.filter(a => !a.resolved);
  const critical = unresolved.filter(a => a.severity === 'critical');
  const warning  = unresolved.filter(a => a.severity === 'warning');
  const info     = unresolved.filter(a => a.severity === 'info');

  // Auto-generate maintenance alerts from data
  const autoAlerts = generateAutoAlerts();

  const html = `
    <div class="page-header">
      <div class="page-header-left">
        <h1>Alertes & Maintenance</h1>
        <p class="page-subtitle">${unresolved.length} alerte(s) active(s) — ${critical.length} critique(s)</p>
      </div>
      <div class="page-actions">
        <button class="btn btn-outline btn-sm" onclick="resolveAllAlerts()"><i data-lucide="check-circle"></i> Tout résoudre</button>
        <button class="btn btn-primary" onclick="openAlertModal()"><i data-lucide="plus"></i> Nouvelle alerte</button>
      </div>
    </div>

    <!-- KPIs -->
    <div class="kpi-grid" style="margin-bottom:var(--space-5)">
      <div class="kpi-card danger">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--danger-light);color:var(--danger)"><i data-lucide="zap"></i></div></div>
        <div class="kpi-value">${critical.length}</div>
        <div class="kpi-label">Critiques</div>
        <div class="kpi-sublabel">Action immédiate requise</div>
      </div>
      <div class="kpi-card warning">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--warning-light);color:var(--warning)"><i data-lucide="alert-triangle"></i></div></div>
        <div class="kpi-value">${warning.length}</div>
        <div class="kpi-label">Avertissements</div>
        <div class="kpi-sublabel">À traiter rapidement</div>
      </div>
      <div class="kpi-card info">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--info-light);color:var(--info)"><i data-lucide="info"></i></div></div>
        <div class="kpi-value">${info.length}</div>
        <div class="kpi-label">Informations</div>
        <div class="kpi-sublabel">Pour votre information</div>
      </div>
      <div class="kpi-card success">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--success-light);color:var(--success)"><i data-lucide="check-circle"></i></div></div>
        <div class="kpi-value">${alerts.filter(a=>a.resolved).length}</div>
        <div class="kpi-label">Résolues</div>
        <div class="kpi-sublabel">Total archivées</div>
      </div>
    </div>

    <!-- Tabs -->
    <div class="tabs" id="alerts-tabs">
      <button class="tab-btn active" onclick="switchAlertsTab('active',this)">
        <i data-lucide="bell"></i> Actives <span class="badge badge-danger" style="margin-left:4px">${unresolved.length}</span>
      </button>
      <button class="tab-btn" onclick="switchAlertsTab('maintenance',this)">
        <i data-lucide="wrench"></i> Maintenance préventive
      </button>
      <button class="tab-btn" onclick="switchAlertsTab('resolved',this)">
        <i data-lucide="check"></i> Résolues
      </button>
    </div>

    <div id="alerts-tab-content"></div>
  `;

  document.getElementById('page-content').innerHTML = html;
  lucide.createIcons();
  renderActiveAlerts(unresolved);
}

function switchAlertsTab(tab, btn) {
  document.querySelectorAll('#alerts-tabs .tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const alerts = DB.alerts();
  if (tab === 'active') renderActiveAlerts(alerts.filter(a => !a.resolved));
  else if (tab === 'maintenance') renderMaintenanceSchedule();
  else renderActiveAlerts(alerts.filter(a => a.resolved), true);
}

function renderActiveAlerts(alerts, resolved = false) {
  const icons = { maintenance:'wrench', insurance:'shield', payment:'banknote', license:'credit-card', vehicle:'car', fuel:'fuel', other:'bell' };
  const container = document.getElementById('alerts-tab-content');
  if (!container) return;

  if (alerts.length === 0) {
    container.innerHTML = `<div class="empty-state">
      <div class="empty-state-icon"><i data-lucide="check-circle-2"></i></div>
      <h3>${resolved ? 'Aucune alerte résolue' : 'Aucune alerte active'}</h3>
      <p>${resolved ? 'Les alertes résolues apparaîtront ici' : 'Toutes vos alertes sont résolues 🎉'}</p>
    </div>`;
    lucide.createIcons();
    return;
  }

  container.innerHTML = `<div style="display:flex;flex-direction:column;gap:0">
    ${alerts.sort((a,b) => { const sev={critical:0,warning:1,info:2}; return (sev[a.severity]||3)-(sev[b.severity]||3); })
      .map(a => {
        const vehicle = a.vehicleId ? Stats.vehicleById(a.vehicleId) : null;
        return `<div class="alert-item ${a.severity}" id="alert-${a.id}">
          <div class="alert-icon"><i data-lucide="${icons[a.type]||'bell'}"></i></div>
          <div class="alert-body">
            <div class="alert-title">${a.title}</div>
            <div class="alert-desc">${a.description}</div>
            <div class="alert-meta">
              ${vehicle ? `<span>🚗 ${vehicle.plate}</span>` : ''}
              <span>📅 ${fmtDate(a.date)}</span>
              <span class="badge ${a.severity==='critical'?'badge-danger':a.severity==='warning'?'badge-warning':'badge-info'}">${a.severity}</span>
            </div>
          </div>
          <div class="alert-actions">
            ${!resolved ? `<button class="btn btn-sm btn-success" onclick="resolveAlert('${a.id}')"><i data-lucide="check"></i> Résoudre</button>` : ''}
            <button class="btn btn-sm btn-outline" onclick="openAlertModal('${a.id}')"><i data-lucide="pencil"></i></button>
            <button class="btn btn-sm btn-ghost" onclick="deleteAlert('${a.id}')" style="color:var(--danger)"><i data-lucide="trash-2"></i></button>
          </div>
        </div>`;
      }).join('')}
  </div>`;
  lucide.createIcons();
}

function renderMaintenanceSchedule() {
  const vehicles = DB.vehicles();
  const container = document.getElementById('alerts-tab-content');
  if (!container) return;

  const sorted = [...vehicles].sort((a,b) => daysFromNow(a.nextMaintenance) - daysFromNow(b.nextMaintenance));

  container.innerHTML = `
    <div class="card">
      <div class="card-header">
        <span class="card-title"><i data-lucide="calendar-check"></i> Calendrier de maintenance préventive</span>
        <button class="btn btn-primary btn-sm" onclick="openScheduleMaintenance()"><i data-lucide="plus"></i> Planifier</button>
      </div>
      <div class="table-wrapper" style="border:none;border-radius:0">
        <table class="table">
          <thead><tr><th>Véhicule</th><th>Conducteur</th><th>Prochaine maintenance</th><th>Dans</th><th>Statut</th><th>Actions</th></tr></thead>
          <tbody>
            ${sorted.map(v => {
              const days = daysFromNow(v.nextMaintenance);
              const driver = v.driverId ? Stats.driverById(v.driverId) : null;
              const urgency = days < 0 ? ['badge-danger','Dépassé'] : days < 7 ? ['badge-danger','Urgent'] : days < 30 ? ['badge-warning','Bientôt'] : ['badge-success','OK'];
              return `<tr>
                <td>
                  <div class="font-bold font-mono text-sm">${v.plate}</div>
                  <div class="text-xs text-muted">${v.brand} ${v.model}</div>
                </td>
                <td class="text-sm">${driver?driver.firstName+' '+driver.lastName:'—'}</td>
                <td class="text-sm">${fmtDate(v.nextMaintenance)}</td>
                <td class="${days<0?'text-danger':days<7?'text-danger':days<30?'text-warning':'text-success'} font-bold text-sm">
                  ${days < 0 ? `${Math.abs(days)}j dépassé` : days === 0 ? 'Aujourd\'hui' : `${days} jour(s)`}
                </td>
                <td><span class="badge ${urgency[0]}">${urgency[1]}</span></td>
                <td>
                  <div class="table-actions">
                    <button class="btn btn-sm btn-primary" onclick="markMaintenanceDone('${v.id}')"><i data-lucide="wrench"></i> Fait</button>
                    <button class="btn btn-sm btn-outline" onclick="openRescheduleMaintenance('${v.id}')"><i data-lucide="calendar"></i> Reporter</button>
                  </div>
                </td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Maintenance History Timeline -->
    <div class="card mt-4">
      <div class="card-header"><span class="card-title"><i data-lucide="clock"></i> Historique maintenance</span></div>
      <div class="card-body">
        <div class="timeline">
          ${DB.expenses().filter(e=>e.category==='maintenance').sort((a,b)=>b.date.localeCompare(a.date)).slice(0,8).map(e => {
            const v = Stats.vehicleById(e.vehicleId);
            return `<div class="timeline-item">
              <div class="timeline-dot"></div>
              <div class="timeline-content">
                <div class="timeline-header">
                  <div class="timeline-title">${e.description}</div>
                  <div class="timeline-time">${fmtDate(e.date)}</div>
                </div>
                <div class="timeline-desc">${v?v.plate+' — ':''} ${fmtCurrency(e.amount)} · ${e.paidBy}</div>
              </div>
            </div>`;
          }).join('')}
        </div>
      </div>
    </div>
  `;
  lucide.createIcons();
}

function generateAutoAlerts() {
  const auto = [];
  DB.vehicles().forEach(v => {
    const maintDays = daysFromNow(v.nextMaintenance);
    if (maintDays < 0) auto.push({ type:'maintenance', severity:'critical', label:`${v.plate}: Maintenance dépassée de ${Math.abs(maintDays)}j` });
    else if (maintDays <= 7) auto.push({ type:'maintenance', severity:'warning', label:`${v.plate}: Maintenance dans ${maintDays}j` });
    const insDays = daysFromNow(v.insuranceExpiry);
    if (insDays < 0) auto.push({ type:'insurance', severity:'critical', label:`${v.plate}: Assurance expirée !` });
    else if (insDays <= 30) auto.push({ type:'insurance', severity:'warning', label:`${v.plate}: Assurance expire dans ${insDays}j` });
  });
  DB.drivers().forEach(d => {
    const licDays = daysFromNow(d.licenseExpiry);
    if (licDays < 0) auto.push({ type:'license', severity:'critical', label:`${d.firstName} ${d.lastName}: Permis expiré !` });
    else if (licDays <= 90) auto.push({ type:'license', severity:'warning', label:`${d.firstName} ${d.lastName}: Permis expire dans ${licDays}j` });
  });
  return auto;
}

function resolveAlert(id) {
  const alerts = DB.alerts();
  const idx = alerts.findIndex(a => a.id === id);
  if (idx > -1) { alerts[idx].resolved = true; DB.saveAlerts(alerts); }
  showToast('success', 'Résolu', 'Alerte marquée comme résolue');
  renderAlerts();
  updateBadges();
}

function resolveAllAlerts() {
  const alerts = DB.alerts().map(a => ({ ...a, resolved: true }));
  DB.saveAlerts(alerts);
  showToast('success', 'Fait', 'Toutes les alertes ont été résolues');
  renderAlerts();
  updateBadges();
}

function deleteAlert(id) {
  DB.saveAlerts(DB.alerts().filter(a => a.id !== id));
  showToast('success', 'Supprimée', 'Alerte supprimée');
  renderAlerts();
  updateBadges();
}

function openAlertModal(id = null) {
  const a = id ? DB.alerts().find(x=>x.id===id) : null;
  const body = `<form>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label required">Type</label>
        <select class="form-control" id="af-type">
          ${['maintenance','insurance','payment','license','vehicle','fuel','other'].map(t=>`<option value="${t}" ${a?.type===t?'selected':''}>${t.charAt(0).toUpperCase()+t.slice(1)}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Sévérité</label>
        <select class="form-control" id="af-sev">
          <option value="critical" ${a?.severity==='critical'?'selected':''}>🔴 Critique</option>
          <option value="warning" ${a?.severity==='warning'?'selected':''}>🟡 Avertissement</option>
          <option value="info" ${a?.severity==='info'?'selected':''}>🔵 Info</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label required">Titre</label>
      <input class="form-control" id="af-title" value="${a?.title||''}" placeholder="Titre de l'alerte" required />
    </div>
    <div class="form-group">
      <label class="form-label required">Description</label>
      <textarea class="form-control" id="af-desc" rows="3" required>${a?.description||''}</textarea>
    </div>
    <div class="form-group">
      <label class="form-label">Véhicule concerné</label>
      <select class="form-control" id="af-vehicle">
        <option value="">— Aucun —</option>
        ${DB.vehicles().map(v=>`<option value="${v.id}" ${a?.vehicleId===v.id?'selected':''}>${v.plate}</option>`).join('')}
      </select>
    </div>
  </form>`;

  openModal(a ? 'Modifier l\'alerte' : 'Nouvelle alerte', body, [
    { label: 'Annuler', cls: 'btn-outline', action: closeModal },
    { label: 'Enregistrer', cls: 'btn-primary', action: () => saveAlert(id) }
  ]);
}

function saveAlert(id) {
  const title = document.getElementById('af-title')?.value.trim();
  const desc  = document.getElementById('af-desc')?.value.trim();
  if (!title || !desc) { showToast('error','Erreur','Champs obligatoires'); return; }
  const data = {
    type: document.getElementById('af-type').value,
    severity: document.getElementById('af-sev').value,
    title, description: desc,
    vehicleId: document.getElementById('af-vehicle').value || null,
    date: today(), resolved: false,
  };
  const alerts = DB.alerts();
  if (id) {
    const idx = alerts.findIndex(a=>a.id===id);
    if (idx>-1) alerts[idx] = { ...alerts[idx], ...data };
  } else {
    alerts.push({ id: uid(), ...data });
  }
  DB.saveAlerts(alerts);
  showToast('success','Enregistrée','Alerte sauvegardée');
  closeModal();
  renderAlerts();
  updateBadges();
}

function markMaintenanceDone(vehicleId) {
  const vehicles = DB.vehicles();
  const idx = vehicles.findIndex(v=>v.id===vehicleId);
  if (idx > -1) {
    const nextDate = new Date();
    nextDate.setMonth(nextDate.getMonth() + 3);
    vehicles[idx].nextMaintenance = nextDate.toISOString().split('T')[0];
    vehicles[idx].km = vehicles[idx].km + randomBetween(0, 500);
    DB.saveVehicles(vehicles);
    const expense = {
      id: uid(), vehicleId, category: 'maintenance',
      amount: 150000, date: today(),
      description: 'Maintenance périodique effectuée',
      reference: 'MAINT-'+Date.now(), paidBy: 'Caisse', notes: ''
    };
    const expenses = DB.expenses();
    expenses.push(expense);
    DB.saveExpenses(expenses);
    showToast('success','Maintenance effectuée','Prochaine maintenance dans 3 mois');
    renderMaintenanceSchedule();
  }
}

function openRescheduleMaintenance(vehicleId) {
  const v = Stats.vehicleById(vehicleId);
  const body = `<div class="form-group">
    <label class="form-label">Nouvelle date de maintenance pour ${v?.plate}</label>
    <input class="form-control" id="reschedule-date" type="date" value="${v?.nextMaintenance||today()}" />
  </div>`;
  openModal('Reporter la maintenance', body, [
    { label: 'Annuler', cls: 'btn-outline', action: closeModal },
    { label: 'Reporter', cls: 'btn-primary', action: () => {
      const newDate = document.getElementById('reschedule-date')?.value;
      if (!newDate) return;
      const vehicles = DB.vehicles();
      const idx = vehicles.findIndex(vx=>vx.id===vehicleId);
      if (idx>-1) { vehicles[idx].nextMaintenance = newDate; DB.saveVehicles(vehicles); }
      showToast('success','Reportée','Maintenance reportée au '+fmtDate(newDate));
      closeModal();
      renderMaintenanceSchedule();
    }}
  ]);
}

function openScheduleMaintenance() {
  openAlertModal();
}
