/* ============================================================
   FLOTTE 2.0 — Payments Module
   ============================================================ */

let paymentFilter = { search: '', status: '', period: '' };

function renderPayments() {
  const payments = DB.payments();
  const totalPaid    = payments.filter(p=>p.status==='paid').reduce((s,p)=>s+p.amount,0);
  const totalPending = payments.filter(p=>p.status==='pending').reduce((s,p)=>s+p.amount,0);
  const totalLate    = payments.filter(p=>p.status==='late').reduce((s,p)=>s+p.amount,0);

  const html = `
    <div class="page-header">
      <div class="page-header-left">
        <h1>Versements & Paiements</h1>
        <p class="page-subtitle">Suivi des versements journaliers des conducteurs</p>
      </div>
      <div class="page-actions">
        <button class="btn btn-outline btn-sm" onclick="exportPaymentsCSV()"><i data-lucide="download"></i> Exporter CSV</button>
        <button class="btn btn-primary" id="add-payment-btn" onclick="openPaymentModal()"><i data-lucide="plus"></i> Nouveau versement</button>
      </div>
    </div>

    <div class="kpi-grid" style="margin-bottom:var(--space-5)">
      <div class="kpi-card success">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--success-light);color:var(--success)"><i data-lucide="circle-check"></i></div></div>
        <div class="kpi-value">${fmtNum(Math.round(totalPaid/1000))}k</div>
        <div class="kpi-label">Total perçu</div>
        <div class="kpi-sublabel">${payments.filter(p=>p.status==='paid').length} versements</div>
      </div>
      <div class="kpi-card warning">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--warning-light);color:var(--warning)"><i data-lucide="clock"></i></div></div>
        <div class="kpi-value">${fmtNum(Math.round(totalPending/1000))}k</div>
        <div class="kpi-label">En attente</div>
        <div class="kpi-sublabel">${payments.filter(p=>p.status==='pending').length} versements</div>
      </div>
      <div class="kpi-card danger">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--danger-light);color:var(--danger)"><i data-lucide="alert-circle"></i></div></div>
        <div class="kpi-value">${fmtNum(Math.round(totalLate/1000))}k</div>
        <div class="kpi-label">En retard</div>
        <div class="kpi-sublabel">${payments.filter(p=>p.status==='late').length} versements</div>
      </div>
      <div class="kpi-card accent">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--accent-light);color:var(--accent)"><i data-lucide="banknote"></i></div></div>
        <div class="kpi-value">${fmtNum(Math.round((totalPaid+totalPending+totalLate)/1000))}k</div>
        <div class="kpi-label">Total attendu</div>
        <div class="kpi-sublabel">${payments.length} versements</div>
      </div>
    </div>

    <!-- Tabs -->
    <div class="tabs" id="payment-tabs">
      <button class="tab-btn active" onclick="switchPaymentTab('table',this)"><i data-lucide="list"></i> Liste</button>
      <button class="tab-btn" onclick="switchPaymentTab('calendar',this)"><i data-lucide="calendar"></i> Calendrier</button>
      <button class="tab-btn" onclick="switchPaymentTab('summary',this)"><i data-lucide="bar-chart-2"></i> Résumé par conducteur</button>
    </div>

    <div id="payment-tab-content"></div>
  `;
  document.getElementById('page-content').innerHTML = html;
  lucide.createIcons();
  renderPaymentTable();
}

function switchPaymentTab(tab, btn) {
  document.querySelectorAll('#payment-tabs .tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  if (tab === 'table') renderPaymentTable();
  else if (tab === 'calendar') renderPaymentCalendar();
  else renderPaymentSummary();
}

function renderPaymentTable() {
  const payments = DB.payments().filter(p => {
    const q = paymentFilter.search.toLowerCase();
    const driver = Stats.driverById(p.driverId);
    const dName = driver ? (driver.firstName+' '+driver.lastName).toLowerCase() : '';
    const vehicle = Stats.vehicleById(p.vehicleId);
    const plate = vehicle ? vehicle.plate.toLowerCase() : '';
    const matchS = !q || dName.includes(q) || plate.includes(q);
    const matchStatus = !paymentFilter.status || p.status === paymentFilter.status;
    return matchS && matchStatus;
  }).sort((a,b) => b.date.localeCompare(a.date));

  const html = `
    <div class="filter-bar" style="margin-bottom:var(--space-4)">
      <div class="search-box">
        <i data-lucide="search"></i>
        <input type="text" placeholder="Conducteur, plaque..." id="pay-search" oninput="filterPayments()" value="${paymentFilter.search}" />
      </div>
      <select class="filter-select" id="pay-status-filter" onchange="filterPayments()">
        <option value="">Tous les statuts</option>
        <option value="paid" ${paymentFilter.status==='paid'?'selected':''}>Payés</option>
        <option value="pending" ${paymentFilter.status==='pending'?'selected':''}>En attente</option>
        <option value="late" ${paymentFilter.status==='late'?'selected':''}>En retard</option>
      </select>
      <span class="text-sm text-muted" style="margin-left:auto">${payments.length} résultat(s)</span>
    </div>
    <div class="table-wrapper">
      <table class="table">
        <thead>
          <tr>
            <th>Conducteur</th><th>Véhicule</th><th>Montant</th><th>Date</th>
            <th>Période</th><th>Méthode</th><th>Statut</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${payments.length === 0 ? `<tr><td colspan="8" style="text-align:center;padding:40px;color:var(--text-muted)">Aucun versement trouvé</td></tr>` :
            payments.map(p => {
              const driver = Stats.driverById(p.driverId);
              const vehicle = Stats.vehicleById(p.vehicleId);
              const sMap = { paid:['badge-success','Payé'], pending:['badge-warning','En attente'], late:['badge-danger','En retard'] };
              const [sCls, sLabel] = sMap[p.status] || ['badge-muted', p.status];
              return `<tr class="payment-row-${p.status}">
                <td>
                  <div style="display:flex;align-items:center;gap:8px">
                    <div class="avatar" style="width:28px;height:28px;font-size:0.68rem">${driver?initials(driver.firstName+' '+driver.lastName):'?'}</div>
                    <span>${driver?driver.firstName+' '+driver.lastName:'—'}</span>
                  </div>
                </td>
                <td><code style="font-family:var(--font-mono);font-size:0.8rem">${vehicle?vehicle.plate:'—'}</code></td>
                <td><strong class="font-mono">${fmtCurrency(p.amount)}</strong></td>
                <td>${fmtDateShort(p.date)}</td>
                <td><span class="badge badge-muted">${p.period}</span></td>
                <td>${p.method}</td>
                <td><span class="badge ${sCls}"><span class="status-dot"></span>${sLabel}</span></td>
                <td>
                  <div class="table-actions">
                    ${p.status !== 'paid' ? `<button class="btn btn-sm btn-success" onclick="markPaymentPaid('${p.id}')" title="Marquer payé"><i data-lucide="check"></i></button>` : ''}
                    <button class="btn btn-icon btn-ghost btn-sm" onclick="openPaymentModal('${p.id}')" title="Modifier"><i data-lucide="pencil"></i></button>
                    <button class="btn btn-icon btn-ghost btn-sm" onclick="deletePayment('${p.id}')" title="Supprimer" style="color:var(--danger)"><i data-lucide="trash-2"></i></button>
                  </div>
                </td>
              </tr>`;
            }).join('')
          }
        </tbody>
      </table>
    </div>
  `;
  document.getElementById('payment-tab-content').innerHTML = html;
  lucide.createIcons();
}

function filterPayments() {
  paymentFilter.search = document.getElementById('pay-search')?.value || '';
  paymentFilter.status = document.getElementById('pay-status-filter')?.value || '';
  renderPaymentTable();
}

function renderPaymentCalendar() {
  const payments = DB.payments();
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay  = new Date(year, month + 1, 0);
  const firstDow = (firstDay.getDay() + 6) % 7; // Monday start

  const dateMap = {};
  payments.forEach(p => {
    if (!dateMap[p.date]) dateMap[p.date] = { paid:0, pending:0, late:0, total:0 };
    dateMap[p.date][p.status]++;
    dateMap[p.date].total++;
  });

  const monthName = now.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
  const days = ['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'];

  let calDays = '';
  for (let i = 0; i < firstDow; i++) calDays += `<div class="cal-day other-month"></div>`;
  for (let d = 1; d <= lastDay.getDate(); d++) {
    const dateStr = `${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const isToday = dateStr === today();
    const dayData = dateMap[dateStr];
    const hasLate = dayData?.late > 0;
    const hasPay  = dayData?.total > 0;

    calDays += `<div class="cal-day ${isToday?'today':''} ${hasLate?'has-late':hasPay?'has-payment':''}" 
      title="${dayData ? `${dayData.total} versement(s) — Payés: ${dayData.paid}, En attente: ${dayData.pending}, En retard: ${dayData.late}` : ''}"
      onclick="showDayPayments('${dateStr}')">
      <span>${d}</span>
      ${dayData ? `<span style="font-size:0.6rem;color:var(--text-muted)">${dayData.total}</span>` : ''}
    </div>`;
  }

  const html = `
    <div class="card">
      <div class="card-header">
        <span class="card-title"><i data-lucide="calendar"></i> ${monthName.charAt(0).toUpperCase()+monthName.slice(1)}</span>
        <div style="display:flex;align-items:center;gap:16px;font-size:0.78rem">
          <span style="display:flex;align-items:center;gap:6px"><span style="width:8px;height:8px;border-radius:50%;background:var(--accent);display:inline-block"></span>Versement</span>
          <span style="display:flex;align-items:center;gap:6px"><span style="width:8px;height:8px;border-radius:50%;background:var(--danger);display:inline-block"></span>En retard</span>
        </div>
      </div>
      <div class="card-body">
        <div class="cal-header">${days.map(d=>`<span>${d}</span>`).join('')}</div>
        <div class="calendar-grid">${calDays}</div>
      </div>
    </div>
    <div id="day-payments-detail" style="margin-top:16px"></div>
  `;
  document.getElementById('payment-tab-content').innerHTML = html;
  lucide.createIcons();
}

function showDayPayments(dateStr) {
  const payments = DB.payments().filter(p => p.date === dateStr);
  const container = document.getElementById('day-payments-detail');
  if (!container) return;
  if (payments.length === 0) { container.innerHTML = ''; return; }

  const sMap = { paid:['badge-success','Payé'], pending:['badge-warning','En attente'], late:['badge-danger','En retard'] };
  container.innerHTML = `
    <div class="card">
      <div class="card-header"><span class="card-title">Versements du ${fmtDate(dateStr)}</span></div>
      <div class="table-wrapper" style="border:none;border-radius:0">
        <table class="table">
          <thead><tr><th>Conducteur</th><th>Véhicule</th><th>Montant</th><th>Méthode</th><th>Statut</th></tr></thead>
          <tbody>
            ${payments.map(p => {
              const d = Stats.driverById(p.driverId);
              const v = Stats.vehicleById(p.vehicleId);
              const [cls,lbl] = sMap[p.status]||['badge-muted',p.status];
              return `<tr><td>${d?d.firstName+' '+d.lastName:'—'}</td><td class="font-mono">${v?v.plate:'—'}</td>
                <td class="font-mono"><strong>${fmtCurrency(p.amount)}</strong></td>
                <td>${p.method}</td><td><span class="badge ${cls}">${lbl}</span></td></tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
  lucide.createIcons();
}

function renderPaymentSummary() {
  const drivers = DB.drivers();
  const html = `
    <div class="table-wrapper">
      <table class="table">
        <thead>
          <tr><th>Conducteur</th><th>Véhicule</th><th>Versements payés</th><th>Total perçu</th><th>En attente</th><th>En retard</th><th>Taux collecte</th></tr>
        </thead>
        <tbody>
          ${drivers.map(d => {
            const dPayments = DB.payments().filter(p => p.driverId === d.id);
            const paid    = dPayments.filter(p=>p.status==='paid');
            const pending = dPayments.filter(p=>p.status==='pending');
            const late    = dPayments.filter(p=>p.status==='late');
            const total   = dPayments.length;
            const paidAmt = paid.reduce((s,p)=>s+p.amount,0);
            const lateAmt = late.reduce((s,p)=>s+p.amount,0);
            const pendingAmt = pending.reduce((s,p)=>s+p.amount,0);
            const rate = total > 0 ? Math.round(paid.length / total * 100) : 0;
            const v = d.vehicleId ? Stats.vehicleById(d.vehicleId) : null;
            return `<tr>
              <td><div style="display:flex;align-items:center;gap:8px">
                <div class="avatar" style="width:28px;height:28px;font-size:0.68rem">${initials(d.firstName+' '+d.lastName)}</div>
                <div><div class="font-bold" style="font-size:0.875rem">${d.firstName} ${d.lastName}</div>
                <div class="text-xs text-muted">${d.phone}</div></div>
              </div></td>
              <td class="font-mono text-sm">${v?v.plate:'—'}</td>
              <td><span class="badge badge-success">${paid.length}</span></td>
              <td class="font-mono text-accent"><strong>${fmtCurrency(paidAmt)}</strong></td>
              <td class="font-mono text-warning">${fmtCurrency(pendingAmt)}</td>
              <td class="font-mono text-danger">${fmtCurrency(lateAmt)}</td>
              <td>
                <div style="display:flex;align-items:center;gap:8px">
                  <div style="flex:1;height:6px;background:var(--bg-hover);border-radius:3px;overflow:hidden">
                    <div style="height:100%;width:${rate}%;background:${rate>=80?'var(--success)':rate>=50?'var(--warning)':'var(--danger)'};border-radius:3px"></div>
                  </div>
                  <span style="font-size:0.78rem;font-weight:700;color:${rate>=80?'var(--success)':rate>=50?'var(--warning)':'var(--danger)'}">${rate}%</span>
                </div>
              </td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
  document.getElementById('payment-tab-content').innerHTML = html;
  lucide.createIcons();
}

function openPaymentModal(id = null) {
  const p = id ? DB.payments().find(x => x.id === id) : null;
  const drivers = DB.drivers().filter(d => d.status === 'active');
  const vehicles = DB.vehicles();

  const body = `<form id="payment-form">
    <div class="form-row">
      <div class="form-group">
        <label class="form-label required">Conducteur</label>
        <select class="form-control" id="pf-driver" onchange="prefillPaymentVehicle()" required>
          <option value="">— Sélectionner —</option>
          ${drivers.map(d=>`<option value="${d.id}" ${p?.driverId===d.id?'selected':''}>${d.firstName} ${d.lastName}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label required">Véhicule</label>
        <select class="form-control" id="pf-vehicle" required>
          <option value="">— Sélectionner —</option>
          ${vehicles.map(v=>`<option value="${v.id}" ${p?.vehicleId===v.id?'selected':''}>${v.plate} — ${v.brand} ${v.model}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label required">Montant (FCFA)</label>
        <input class="form-control" id="pf-amount" type="number" min="0" value="${p?.amount||35000}" required />
      </div>
      <div class="form-group">
        <label class="form-label required">Date</label>
        <input class="form-control" id="pf-date" type="date" value="${p?.date||today()}" required />
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Période</label>
        <select class="form-control" id="pf-period">
          ${['Journalier','Hebdomadaire','Mensuel'].map(x=>`<option ${p?.period===x?'selected':''}>${x}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Méthode de paiement</label>
        <select class="form-control" id="pf-method">
          ${['Espèces','Mobile Money','Virement','Chèque'].map(x=>`<option ${p?.method===x?'selected':''}>${x}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Statut</label>
        <select class="form-control" id="pf-status">
          <option value="paid" ${p?.status==='paid'?'selected':''}>Payé</option>
          <option value="pending" ${p?.status==='pending'?'selected':''}>En attente</option>
          <option value="late" ${p?.status==='late'?'selected':''}>En retard</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Notes</label>
      <textarea class="form-control" id="pf-notes" rows="2">${p?.notes||''}</textarea>
    </div>
  </form>`;

  openModal(p ? 'Modifier le versement' : 'Nouveau versement', body, [
    { label: 'Annuler', cls: 'btn-outline', action: closeModal },
    { label: p ? 'Mettre à jour' : 'Enregistrer', cls: 'btn-primary', action: () => savePayment(id) }
  ]);
}

function prefillPaymentVehicle() {
  const driverId = document.getElementById('pf-driver')?.value;
  if (!driverId) return;
  const driver = Stats.driverById(driverId);
  if (driver?.vehicleId) {
    const sel = document.getElementById('pf-vehicle');
    if (sel) { sel.value = driver.vehicleId; }
    const v = Stats.vehicleById(driver.vehicleId);
    if (v) { const amtField = document.getElementById('pf-amount'); if (amtField) amtField.value = v.dailyTarget; }
  }
}

function savePayment(id) {
  const driverId  = document.getElementById('pf-driver')?.value;
  const vehicleId = document.getElementById('pf-vehicle')?.value;
  const amount    = +document.getElementById('pf-amount')?.value;
  const date      = document.getElementById('pf-date')?.value;
  if (!driverId || !vehicleId || !amount || !date) { showToast('error','Erreur','Champs obligatoires manquants'); return; }

  const data = { driverId, vehicleId, amount, date,
    period: document.getElementById('pf-period').value,
    method: document.getElementById('pf-method').value,
    status: document.getElementById('pf-status').value,
    notes:  document.getElementById('pf-notes').value,
  };

  const payments = DB.payments();
  if (id) {
    const idx = payments.findIndex(p => p.id === id);
    if (idx > -1) payments[idx] = { ...payments[idx], ...data };
    showToast('success','Mis à jour','Versement modifié');
  } else {
    payments.push({ id: uid(), ...data });
    showToast('success','Enregistré',`Versement de ${fmtCurrency(amount)} enregistré`);
  }
  DB.savePayments(payments);
  closeModal();
  renderPayments();
  updateBadges();
}

function markPaymentPaid(id) {
  const payments = DB.payments();
  const idx = payments.findIndex(p => p.id === id);
  if (idx > -1) { payments[idx].status = 'paid'; DB.savePayments(payments); }
  showToast('success','Payé','Versement marqué comme payé');
  renderPaymentTable();
  updateBadges();
}

function deletePayment(id) {
  DB.savePayments(DB.payments().filter(p => p.id !== id));
  showToast('success','Supprimé','Versement supprimé');
  renderPaymentTable();
  updateBadges();
}

function exportPaymentsCSV() {
  const rows = [['Date','Conducteur','Véhicule','Montant','Période','Méthode','Statut','Notes']];
  DB.payments().sort((a,b)=>b.date.localeCompare(a.date)).forEach(p => {
    const d = Stats.driverById(p.driverId);
    const v = Stats.vehicleById(p.vehicleId);
    rows.push([p.date, d?d.firstName+' '+d.lastName:'', v?v.plate:'', p.amount, p.period, p.method, p.status, p.notes]);
  });
  downloadCSV(rows, 'versements_flotte2.csv');
}
