/* ============================================================
   FLOTTE 2.0 — Chart.js Configurations
   ============================================================ */

const CHART_COLORS = {
  accent:    '#00C9A7',
  secondary: '#6366F1',
  success:   '#3FB950',
  warning:   '#D29922',
  danger:    '#F85149',
  info:      '#388BFD',
  gold:      '#F0A500',
  muted:     '#484F58',
};

const CHART_DEFAULTS = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      labels: {
        color: '#8B949E',
        font: { family: 'Inter', size: 12 },
        usePointStyle: true,
        pointStyleWidth: 10,
      }
    },
    tooltip: {
      backgroundColor: '#21262D',
      borderColor: '#30363D',
      borderWidth: 1,
      titleColor: '#E6EDF3',
      bodyColor: '#8B949E',
      padding: 12,
      cornerRadius: 8,
      titleFont: { family: 'Inter', weight: '600' },
      bodyFont: { family: 'Inter' },
    }
  },
  scales: {
    x: {
      grid: { color: 'rgba(48,54,61,0.5)' },
      ticks: { color: '#8B949E', font: { family: 'Inter', size: 11 } },
    },
    y: {
      grid: { color: 'rgba(48,54,61,0.5)' },
      ticks: { color: '#8B949E', font: { family: 'Inter', size: 11 } },
    }
  }
};

Chart.defaults.color = '#8B949E';
Chart.defaults.font.family = 'Inter';

const activeCharts = {};

function destroyChart(id) {
  if (activeCharts[id]) {
    activeCharts[id].destroy();
    delete activeCharts[id];
  }
}

function getCanvas(id) {
  return document.getElementById(id);
}

/* ---- Dashboard: Revenue vs Expenses ---- */
function renderRevenueExpensesChart(data) {
  destroyChart('chart-revenue-expenses');
  const canvas = getCanvas('chart-revenue-expenses');
  if (!canvas) return;

  activeCharts['chart-revenue-expenses'] = new Chart(canvas, {
    type: 'bar',
    data: {
      labels: data.map(d => d.label),
      datasets: [
        {
          label: 'Revenus',
          data: data.map(d => d.revenue),
          backgroundColor: 'rgba(0,201,167,0.7)',
          borderColor: CHART_COLORS.accent,
          borderWidth: 2,
          borderRadius: 6,
          borderSkipped: false,
        },
        {
          label: 'Dépenses',
          data: data.map(d => d.expenses),
          backgroundColor: 'rgba(248,81,73,0.6)',
          borderColor: CHART_COLORS.danger,
          borderWidth: 2,
          borderRadius: 6,
          borderSkipped: false,
        }
      ]
    },
    options: {
      ...CHART_DEFAULTS,
      plugins: {
        ...CHART_DEFAULTS.plugins,
        tooltip: {
          ...CHART_DEFAULTS.plugins.tooltip,
          callbacks: {
            label: ctx => `${ctx.dataset.label}: ${fmtCurrency(ctx.raw)}`
          }
        }
      },
      scales: {
        ...CHART_DEFAULTS.scales,
        y: {
          ...CHART_DEFAULTS.scales.y,
          ticks: {
            ...CHART_DEFAULTS.scales.y.ticks,
            callback: v => fmtNum(Math.round(v/1000)) + 'k'
          }
        }
      },
      interaction: { mode: 'index', intersect: false },
      animation: { duration: 600, easing: 'easeInOutQuart' }
    }
  });
}

/* ---- Dashboard: Fleet Status ---- */
function renderFleetStatusChart(statusCounts) {
  destroyChart('chart-fleet-status');
  const canvas = getCanvas('chart-fleet-status');
  if (!canvas) return;

  activeCharts['chart-fleet-status'] = new Chart(canvas, {
    type: 'doughnut',
    data: {
      labels: ['Actifs', 'Maintenance', 'Inactifs'],
      datasets: [{
        data: [statusCounts.active, statusCounts.maintenance, statusCounts.inactive],
        backgroundColor: [
          'rgba(63,185,80,0.8)',
          'rgba(210,153,34,0.8)',
          'rgba(248,81,73,0.8)',
        ],
        borderColor: [CHART_COLORS.success, CHART_COLORS.warning, CHART_COLORS.danger],
        borderWidth: 2,
        hoverOffset: 6,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '70%',
      plugins: {
        legend: { display: false },
        tooltip: {
          ...CHART_DEFAULTS.plugins.tooltip,
          callbacks: {
            label: ctx => `${ctx.label}: ${ctx.raw} véhicule(s)`
          }
        }
      },
      animation: { duration: 700, easing: 'easeInOutQuart' }
    }
  });
}

/* ---- Expenses: Category Pie ---- */
function renderExpenseCategoryChart(catTotals) {
  destroyChart('chart-expense-cat');
  const canvas = getCanvas('chart-expense-cat');
  if (!canvas) return;

  activeCharts['chart-expense-cat'] = new Chart(canvas, {
    type: 'doughnut',
    data: {
      labels: ['Carburant', 'Maintenance', 'Assurance', 'Amendes', 'Autres'],
      datasets: [{
        data: [catTotals.fuel, catTotals.maintenance, catTotals.insurance, catTotals.fine, catTotals.other],
        backgroundColor: [
          'rgba(210,153,34,0.8)',
          'rgba(56,139,253,0.8)',
          'rgba(99,102,241,0.8)',
          'rgba(248,81,73,0.8)',
          'rgba(72,79,88,0.8)',
        ],
        borderColor: [CHART_COLORS.warning, CHART_COLORS.info, CHART_COLORS.secondary, CHART_COLORS.danger, CHART_COLORS.muted],
        borderWidth: 2,
        hoverOffset: 6,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '60%',
      plugins: {
        legend: { display: false },
        tooltip: {
          ...CHART_DEFAULTS.plugins.tooltip,
          callbacks: { label: ctx => `${ctx.label}: ${fmtCurrency(ctx.raw)}` }
        }
      }
    }
  });
}

/* ---- Expenses: Per Vehicle Bar ---- */
function renderExpenseVehicleChart() {
  destroyChart('chart-expense-vehicle');
  const canvas = getCanvas('chart-expense-vehicle');
  if (!canvas) return;

  const vehicles = DB.vehicles();
  const labels = vehicles.map(v => v.plate);
  const revData = vehicles.map(v => Stats.vehicleRevenue(v.id, 30));
  const expData = vehicles.map(v => Stats.vehicleExpenses(v.id, 30));

  activeCharts['chart-expense-vehicle'] = new Chart(canvas, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        { label: 'Revenus', data: revData, backgroundColor: 'rgba(0,201,167,0.7)', borderColor: CHART_COLORS.accent, borderWidth: 2, borderRadius: 4 },
        { label: 'Dépenses', data: expData, backgroundColor: 'rgba(248,81,73,0.6)', borderColor: CHART_COLORS.danger, borderWidth: 2, borderRadius: 4 },
      ]
    },
    options: {
      ...CHART_DEFAULTS,
      interaction: { mode: 'index', intersect: false },
      scales: {
        ...CHART_DEFAULTS.scales,
        y: { ...CHART_DEFAULTS.scales.y, ticks: { ...CHART_DEFAULTS.scales.y.ticks, callback: v => fmtNum(Math.round(v/1000))+'k' } }
      },
      plugins: { ...CHART_DEFAULTS.plugins, tooltip: { ...CHART_DEFAULTS.plugins.tooltip, callbacks: { label: ctx => `${ctx.dataset.label}: ${fmtCurrency(ctx.raw)}` } } }
    }
  });
}

/* ---- Analytics: Revenue Chart ---- */
function renderAnalyticsRevenueChart(data) {
  destroyChart('analytics-revenue-chart');
  const canvas = getCanvas('analytics-revenue-chart');
  if (!canvas) return;

  activeCharts['analytics-revenue-chart'] = new Chart(canvas, {
    type: 'line',
    data: {
      labels: data.map(d => d.label),
      datasets: [
        {
          label: 'Revenus',
          data: data.map(d => d.revenue),
          borderColor: CHART_COLORS.accent,
          backgroundColor: 'rgba(0,201,167,0.08)',
          borderWidth: 2.5,
          fill: true,
          tension: 0.4,
          pointBackgroundColor: CHART_COLORS.accent,
          pointRadius: 4,
          pointHoverRadius: 6,
        },
        {
          label: 'Dépenses',
          data: data.map(d => d.expenses),
          borderColor: CHART_COLORS.danger,
          backgroundColor: 'rgba(248,81,73,0.06)',
          borderWidth: 2.5,
          fill: true,
          tension: 0.4,
          pointBackgroundColor: CHART_COLORS.danger,
          pointRadius: 4,
          pointHoverRadius: 6,
        }
      ]
    },
    options: {
      ...CHART_DEFAULTS,
      interaction: { mode: 'index', intersect: false },
      scales: {
        ...CHART_DEFAULTS.scales,
        y: { ...CHART_DEFAULTS.scales.y, ticks: { ...CHART_DEFAULTS.scales.y.ticks, callback: v => fmtNum(Math.round(v/1000))+'k' } }
      },
      plugins: { ...CHART_DEFAULTS.plugins, tooltip: { ...CHART_DEFAULTS.plugins.tooltip, callbacks: { label: ctx => `${ctx.dataset.label}: ${fmtCurrency(ctx.raw)}` } } }
    }
  });
}

/* ---- Analytics: Expense Pie ---- */
function renderAnalyticsExpensePie(cats) {
  destroyChart('analytics-expense-pie');
  const canvas = getCanvas('analytics-expense-pie');
  if (!canvas) return;
  renderExpenseCategoryChart(cats);
  // reuse with different canvas id
  destroyChart('analytics-expense-pie');
  const c2 = getCanvas('analytics-expense-pie');
  if (!c2) return;
  activeCharts['analytics-expense-pie'] = new Chart(c2, {
    type: 'doughnut',
    data: {
      labels: ['Carburant','Maintenance','Assurance','Amendes','Autres'],
      datasets: [{
        data: [cats.fuel, cats.maintenance, cats.insurance, cats.fine, cats.other],
        backgroundColor: ['rgba(210,153,34,0.8)','rgba(56,139,253,0.8)','rgba(99,102,241,0.8)','rgba(248,81,73,0.8)','rgba(72,79,88,0.8)'],
        borderColor: [CHART_COLORS.warning, CHART_COLORS.info, CHART_COLORS.secondary, CHART_COLORS.danger, CHART_COLORS.muted],
        borderWidth: 2, hoverOffset: 6,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: '65%',
      plugins: { legend: { position: 'bottom', labels: { color:'#8B949E', font:{family:'Inter',size:11}, usePointStyle:true } },
        tooltip: { ...CHART_DEFAULTS.plugins.tooltip, callbacks: { label: ctx=>`${ctx.label}: ${fmtCurrency(ctx.raw)}` } } }
    }
  });
}

/* ---- Analytics: Monthly Trend ---- */
function renderAnalyticsTrendChart() {
  destroyChart('analytics-trend-chart');
  const canvas = getCanvas('analytics-trend-chart');
  if (!canvas) return;

  const months = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    months.push({ label: d.toLocaleDateString('fr-FR', { month: 'short', year: '2-digit' }), multiplier: 1 - i*0.05 });
  }

  const baseRev = Stats.totalRevenue(30);
  const baseExp = Stats.totalExpenses(30);
  const revData = months.map((m,i) => Math.max(0, baseRev * (0.7 + i*0.06) + randomBetween(-50000,50000)));
  const expData = months.map((m,i) => Math.max(0, baseExp * (0.8 + i*0.04) + randomBetween(-30000,30000)));
  const netData = revData.map((r,i) => r - expData[i]);

  activeCharts['analytics-trend-chart'] = new Chart(canvas, {
    type: 'line',
    data: {
      labels: months.map(m => m.label),
      datasets: [
        { label:'Revenus', data:revData, borderColor:CHART_COLORS.accent, backgroundColor:'rgba(0,201,167,0.06)', borderWidth:2.5, fill:true, tension:0.4, pointRadius:5, pointHoverRadius:7, pointBackgroundColor:CHART_COLORS.accent },
        { label:'Dépenses', data:expData, borderColor:CHART_COLORS.danger, backgroundColor:'rgba(248,81,73,0.04)', borderWidth:2, fill:true, tension:0.4, pointRadius:4, pointHoverRadius:6, pointBackgroundColor:CHART_COLORS.danger },
        { label:'Bénéfice', data:netData, borderColor:CHART_COLORS.secondary, backgroundColor:'rgba(99,102,241,0.05)', borderWidth:2, fill:true, tension:0.4, pointRadius:4, borderDash:[5,3] },
      ]
    },
    options: {
      ...CHART_DEFAULTS,
      interaction: { mode: 'index', intersect: false },
      scales: { ...CHART_DEFAULTS.scales, y: { ...CHART_DEFAULTS.scales.y, ticks: { ...CHART_DEFAULTS.scales.y.ticks, callback: v=>fmtNum(Math.round(v/1000))+'k' } } },
      plugins: { ...CHART_DEFAULTS.plugins, tooltip: { ...CHART_DEFAULTS.plugins.tooltip, callbacks: { label: ctx=>`${ctx.dataset.label}: ${fmtCurrency(ctx.raw)}` } } }
    }
  });
}

/* ---- Settings: Gauge Chart ---- */
function renderGaugeChart(value) {
  destroyChart('settings-gauge-chart');
  const canvas = getCanvas('settings-gauge-chart');
  if (!canvas) return;

  const clamp = Math.max(0, Math.min(100, value));
  activeCharts['settings-gauge-chart'] = new Chart(canvas, {
    type: 'doughnut',
    data: {
      datasets: [{
        data: [clamp, 100 - clamp],
        backgroundColor: [
          clamp >= 50 ? CHART_COLORS.success : clamp >= 20 ? CHART_COLORS.warning : CHART_COLORS.danger,
          'rgba(48,54,61,0.4)'
        ],
        borderWidth: 0,
        hoverOffset: 0,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      cutout: '80%', rotation: -90, circumference: 180,
      plugins: { legend: { display: false }, tooltip: { enabled: false } }
    }
  });
}
