/* ============================================================
   FLOTTE 2.0 — Main App Router & Core Functions
   ============================================================ */

/* ============================================================
   MODAL SYSTEM
   ============================================================ */
function openModal(title, body, actions = [], size = '') {
  const overlay  = document.getElementById('modal-overlay');
  const box      = document.getElementById('modal-box');
  const titleEl  = document.getElementById('modal-title');
  const bodyEl   = document.getElementById('modal-body');
  const footerEl = document.getElementById('modal-footer');

  if (!overlay || !box) return;

  titleEl.textContent = title;
  bodyEl.innerHTML = body;
  footerEl.innerHTML = '';

  // Size
  box.className = 'modal-box ' + size;

  // Footer actions
  actions.forEach(action => {
    const btn = document.createElement('button');
    btn.className = 'btn ' + action.cls;
    btn.textContent = action.label;
    btn.onclick = action.action;
    footerEl.appendChild(btn);
  });

  overlay.classList.remove('hidden');
  lucide.createIcons();

  // Focus trap
  setTimeout(() => {
    const firstInput = bodyEl.querySelector('input, select, textarea, button');
    if (firstInput) firstInput.focus();
  }, 100);
}

function closeModal() {
  const overlay = document.getElementById('modal-overlay');
  if (overlay) overlay.classList.add('hidden');
}

/* ============================================================
   TOAST SYSTEM
   ============================================================ */
function showToast(type, title, message, duration = 4000) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const icons = { success: 'check-circle', error: 'x-circle', warning: 'alert-triangle', info: 'info' };
  const id = 'toast-' + Date.now();

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.id = id;
  toast.innerHTML = `
    <div class="toast-icon"><i data-lucide="${icons[type] || 'info'}"></i></div>
    <div class="toast-content">
      <div class="toast-title">${title}</div>
      ${message ? `<div class="toast-msg">${message}</div>` : ''}
    </div>
    <button class="toast-close" onclick="removeToast('${id}')">&times;</button>
  `;

  container.appendChild(toast);
  lucide.createIcons();

  setTimeout(() => removeToast(id), duration);
}

function removeToast(id) {
  const toast = document.getElementById(id);
  if (!toast) return;
  toast.classList.add('removing');
  setTimeout(() => toast.remove(), 300);
}

/* ============================================================
   NOTIFICATION PANEL
   ============================================================ */
function setupNotificationPanel() {
  const btn   = document.getElementById('notification-btn');
  const panel = document.getElementById('notif-panel');
  if (!btn || !panel) return;

  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    panel.classList.toggle('hidden');
    renderNotifications();
  });

  document.addEventListener('click', (e) => {
    if (!panel.contains(e.target) && e.target !== btn) {
      panel.classList.add('hidden');
    }
  });

  const clearBtn = document.getElementById('notif-clear');
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      const alerts = DB.alerts().map(a => ({ ...a, resolved: true }));
      DB.saveAlerts(alerts);
      renderNotifications();
      updateBadges();
      const dot = document.getElementById('notif-dot');
      if (dot) dot.classList.remove('visible');
    });
  }
}

function renderNotifications() {
  const list = document.getElementById('notif-list');
  if (!list) return;

  const alerts = DB.alerts().filter(a => !a.resolved).slice(0, 10);
  if (alerts.length === 0) {
    list.innerHTML = `<div class="notif-empty"><i data-lucide="bell-off"></i><p>Aucune notification</p></div>`;
    lucide.createIcons();
    return;
  }

  const icons = { maintenance:'wrench', insurance:'shield', payment:'banknote', license:'credit-card', vehicle:'car', other:'bell' };
  const colors = { critical:'var(--danger-light)', warning:'var(--warning-light)', info:'var(--info-light)' };
  const tColors = { critical:'var(--danger)', warning:'var(--warning)', info:'var(--info)' };

  list.innerHTML = alerts.map(a => `
    <div class="notif-item unread" onclick="App.navigate('alerts');document.getElementById('notif-panel').classList.add('hidden')">
      <div class="notif-item-icon" style="background:${colors[a.severity]||'var(--bg-hover)'};color:${tColors[a.severity]||'var(--text-muted)'}">
        <i data-lucide="${icons[a.type]||'bell'}"></i>
      </div>
      <div class="notif-item-body">
        <div class="notif-msg">${a.title}</div>
        <div class="notif-time">${fmtDate(a.date)}</div>
      </div>
    </div>
  `).join('');
  lucide.createIcons();
}

/* ============================================================
   BADGES UPDATE
   ============================================================ */
function updateBadges() {
  const setBadge = (id, count) => {
    const el = document.getElementById(id);
    if (el) { el.textContent = count; el.style.display = count > 0 ? '' : 'none'; }
  };

  setBadge('badge-vehicles', DB.vehicles().length);
  setBadge('badge-drivers',  DB.drivers().filter(d=>d.status==='active').length);
  setBadge('badge-payments', Stats.pendingPayments());
  setBadge('badge-alerts',   Stats.unresolvedAlerts());

  // Notif dot
  const dot = document.getElementById('notif-dot');
  if (dot) dot.classList.toggle('visible', Stats.unresolvedAlerts() > 0);
}

/* ============================================================
   CSV DOWNLOAD
   ============================================================ */
function downloadCSV(rows, filename) {
  const content = rows.map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob(['\uFEFF' + content], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/* ============================================================
   TOPBAR DATE
   ============================================================ */
function updateTopbarDate() {
  const el = document.getElementById('topbar-date');
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleDateString('fr-FR', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' })
    + ' · ' + now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

/* ============================================================
   SPA ROUTER
   ============================================================ */
const PAGES = {
  dashboard: { title: 'Tableau de bord', render: renderDashboard },
  vehicles:  { title: 'Véhicules',       render: renderVehicles },
  drivers:   { title: 'Conducteurs',     render: renderDrivers },
  payments:  { title: 'Versements',      render: renderPayments },
  expenses:  { title: 'Dépenses',        render: renderExpenses },
  tracking:  { title: 'Suivi GPS',       render: renderTracking },
  analytics: { title: 'Analyse',         render: renderAnalytics },
  alerts:    { title: 'Alertes',         render: renderAlerts },
  settings:  { title: 'Paramètres',      render: renderSettings },
};

const App = {
  currentPage: 'dashboard',

  navigate(page) {
    if (!PAGES[page]) return;
    this.currentPage = page;

    // Update URL hash
    history.replaceState(null, '', '#' + page);

    // Active nav
    document.querySelectorAll('.nav-item').forEach(item => {
      const isActive = item.dataset.page === page;
      item.classList.toggle('active', isActive);
      let indicator = item.querySelector('.nav-indicator');
      if (isActive && !indicator) {
        indicator = document.createElement('div');
        indicator.className = 'nav-indicator';
        item.appendChild(indicator);
      } else if (!isActive && indicator) {
        indicator.remove();
      }
    });

    // Page title
    const titleEl = document.getElementById('page-title');
    if (titleEl) titleEl.textContent = PAGES[page].title;

    // Scroll to top
    const content = document.getElementById('page-content');
    if (content) content.scrollTop = 0;

    // Stop tracking interval if leaving tracking page
    if (page !== 'tracking' && typeof trackingInterval !== 'undefined' && trackingInterval) {
      clearInterval(trackingInterval);
      trackingInterval = null;
    }

    // Close mobile sidebar
    const sidebar = document.getElementById('sidebar');
    if (sidebar && sidebar.classList.contains('mobile-open')) {
      sidebar.classList.remove('mobile-open');
    }

    // Render
    try {
      PAGES[page].render();
      lucide.createIcons();
    } catch (err) {
      console.error('Page render error:', err);
      document.getElementById('page-content').innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon"><i data-lucide="alert-circle"></i></div>
          <h3>Erreur de chargement</h3>
          <p>${err.message}</p>
          <button class="btn btn-primary" onclick="App.navigate('dashboard')">Retour au tableau de bord</button>
        </div>`;
      lucide.createIcons();
    }
  },

  init() {
    // Init data
    DB.init();

    // Theme
    const settings = DB.settings();
    document.documentElement.setAttribute('data-theme', settings.theme || 'dark');

    // Render app
    document.getElementById('app').classList.remove('hidden');

    // Nav click handlers
    document.querySelectorAll('.nav-item[data-page]').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        this.navigate(item.dataset.page);
      });
    });

    // Sidebar toggle
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebar = document.getElementById('sidebar');
    if (sidebarToggle && sidebar) {
      sidebarToggle.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        const isCollapsed = sidebar.classList.contains('collapsed');
        const icon = sidebarToggle.querySelector('i');
        if (icon) {
          icon.setAttribute('data-lucide', isCollapsed ? 'panel-left-open' : 'panel-left-close');
          lucide.createIcons();
        }
      });
    }

    // Mobile menu
    const mobileBtn = document.getElementById('mobile-menu-btn');
    if (mobileBtn && sidebar) {
      mobileBtn.addEventListener('click', () => {
        sidebar.classList.toggle('mobile-open');
      });
    }

    // Theme toggle
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
      themeToggle.addEventListener('click', toggleTheme);
    }

    // Modal close
    const modalOverlay = document.getElementById('modal-overlay');
    const modalClose   = document.getElementById('modal-close');
    if (modalClose) modalClose.addEventListener('click', closeModal);
    if (modalOverlay) {
      modalOverlay.addEventListener('click', (e) => {
        if (e.target === modalOverlay) closeModal();
      });
    }

    // Keyboard: Escape closes modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeModal();
    });

    // Notification panel
    setupNotificationPanel();

    // Global search
    const globalSearch = document.getElementById('global-search');
    if (globalSearch) {
      globalSearch.addEventListener('input', (e) => {
        const q = e.target.value.trim();
        if (q.length >= 2) globalSearchHandler(q);
      });
      globalSearch.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          const q = e.target.value.trim();
          if (q) globalSearchHandler(q);
        }
      });
    }

    // Date/time
    updateTopbarDate();
    setInterval(updateTopbarDate, 60000);

    // Badges
    updateBadges();

    // Route from hash
    const hash = window.location.hash.slice(1);
    const startPage = PAGES[hash] ? hash : 'dashboard';
    this.navigate(startPage);

    // Hash change
    window.addEventListener('hashchange', () => {
      const page = window.location.hash.slice(1);
      if (PAGES[page] && page !== this.currentPage) this.navigate(page);
    });
  }
};

/* ============================================================
   GLOBAL SEARCH
   ============================================================ */
function globalSearchHandler(q) {
  const ql = q.toLowerCase();

  // Search vehicles
  const vehicles = DB.vehicles().filter(v =>
    v.plate.toLowerCase().includes(ql) || v.brand.toLowerCase().includes(ql) || v.model.toLowerCase().includes(ql)
  );
  // Search drivers
  const drivers = DB.drivers().filter(d =>
    (d.firstName+' '+d.lastName).toLowerCase().includes(ql) || d.phone.includes(ql)
  );

  if (vehicles.length > 0) {
    App.navigate('vehicles');
    vehicleFilter.search = q;
    setTimeout(renderVehicleList, 100);
  } else if (drivers.length > 0) {
    App.navigate('drivers');
    driverFilter.search = q;
    setTimeout(renderDriverList, 100);
  } else {
    showToast('info', 'Recherche', `Aucun résultat pour "${q}"`);
  }
}

/* ============================================================
   SPLASH SCREEN
   ============================================================ */
function hideSplash() {
  const splash = document.getElementById('splash-screen');
  if (splash) {
    splash.classList.add('fade-out');
    setTimeout(() => splash.remove(), 600);
  }
}

/* ============================================================
   BOOT
   ============================================================ */
window.addEventListener('DOMContentLoaded', () => {
  // Hide splash after load animation
  setTimeout(() => {
    hideSplash();
    App.init();
  }, 2200);
});

// Handle unhandled promise rejections gracefully
window.addEventListener('unhandledrejection', (e) => {
  console.warn('Unhandled rejection:', e.reason);
});
