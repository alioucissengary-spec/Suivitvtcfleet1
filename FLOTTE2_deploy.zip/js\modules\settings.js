/* ============================================================
   FLOTTE 2.0 — Settings Module
   ============================================================ */

function renderSettings() {
  const settings = DB.settings();
  const company = settings.company || FLOTTE.company;

  const html = `
    <div class="page-header">
      <div class="page-header-left">
        <h1>Paramètres</h1>
        <p class="page-subtitle">Configuration de l'application et de votre société</p>
      </div>
    </div>

    <div class="grid-12">
      <!-- Left Column -->
      <div class="col-8">
        <!-- Company Info -->
        <div class="card mb-6">
          <div class="card-header">
            <span class="card-title"><i data-lucide="building-2"></i> Informations de la société</span>
            <button class="btn btn-primary btn-sm" onclick="saveCompanySettings()"><i data-lucide="save"></i> Sauvegarder</button>
          </div>
          <div class="card-body">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label required">Nom de la société</label>
                <input class="form-control" id="s-company-name" value="${company.name}" />
              </div>
              <div class="form-group">
                <label class="form-label">Téléphone</label>
                <input class="form-control" id="s-company-phone" value="${company.phone}" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Email</label>
                <input class="form-control" id="s-company-email" type="email" value="${company.email}" />
              </div>
              <div class="form-group">
                <label class="form-label">Adresse</label>
                <input class="form-control" id="s-company-address" value="${company.address}" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">RIB / Compte bancaire</label>
                <input class="form-control" id="s-company-rib" value="${company.rib}" />
              </div>
              <div class="form-group">
                <label class="form-label">Devise</label>
                <select class="form-control" id="s-currency">
                  <option value="FCFA" ${company.currency==='FCFA'?'selected':''}>FCFA (Franc CFA)</option>
                  <option value="EUR" ${company.currency==='EUR'?'selected':''}>EUR (Euro)</option>
                  <option value="USD" ${company.currency==='USD'?'selected':''}>USD (Dollar)</option>
                  <option value="XOF" ${company.currency==='XOF'?'selected':''}>XOF</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <!-- Users & Roles -->
        <div class="card mb-6">
          <div class="card-header">
            <span class="card-title"><i data-lucide="users-2"></i> Utilisateurs & Rôles</span>
            <button class="btn btn-primary btn-sm" onclick="openAddUserModal()"><i data-lucide="user-plus"></i> Ajouter</button>
          </div>
          <div class="table-wrapper" style="border:none;border-radius:0">
            <table class="table">
              <thead><tr><th>Utilisateur</th><th>Rôle</th><th>Statut</th><th>Actions</th></tr></thead>
              <tbody>
                <tr>
                  <td><div style="display:flex;align-items:center;gap:8px">
                    <div class="avatar" style="width:28px;height:28px;font-size:0.7rem;background:linear-gradient(135deg,var(--accent),var(--secondary))">AD</div>
                    <div><div class="font-bold text-sm">Administrateur</div><div class="text-xs text-muted">admin@flotte2.app</div></div>
                  </div></td>
                  <td><span class="badge badge-accent">Super Admin</span></td>
                  <td><span class="badge badge-success">Actif</span></td>
                  <td><span class="text-muted text-xs">Compte système</span></td>
                </tr>
                <tr>
                  <td><div style="display:flex;align-items:center;gap:8px">
                    <div class="avatar" style="width:28px;height:28px;font-size:0.7rem">GE</div>
                    <div><div class="font-bold text-sm">Gestionnaire</div><div class="text-xs text-muted">gestionnaire@flotte2.app</div></div>
                  </div></td>
                  <td><span class="badge badge-secondary">Gestionnaire</span></td>
                  <td><span class="badge badge-success">Actif</span></td>
                  <td><div class="table-actions">
                    <button class="btn btn-icon btn-ghost btn-sm"><i data-lucide="pencil"></i></button>
                    <button class="btn btn-icon btn-ghost btn-sm" style="color:var(--danger)"><i data-lucide="trash-2"></i></button>
                  </div></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Data Management -->
        <div class="card">
          <div class="card-header">
            <span class="card-title"><i data-lucide="database"></i> Gestion des données</span>
          </div>
          <div class="card-body">
            <div class="settings-row">
              <div class="settings-row-label">
                <strong>Exporter toutes les données</strong>
                <span>Télécharger un backup complet au format JSON</span>
              </div>
              <button class="btn btn-outline btn-sm" onclick="exportAllData()"><i data-lucide="download"></i> Exporter JSON</button>
            </div>
            <div class="settings-row">
              <div class="settings-row-label">
                <strong>Importer des données</strong>
                <span>Restaurer depuis un fichier JSON de sauvegarde</span>
              </div>
              <button class="btn btn-outline btn-sm" onclick="importData()"><i data-lucide="upload"></i> Importer</button>
            </div>
            <div class="settings-row">
              <div class="settings-row-label">
                <strong>Réinitialiser les données de démonstration</strong>
                <span>Recharger les données d'exemple (irréversible)</span>
              </div>
              <button class="btn btn-danger btn-sm" onclick="resetToSeedData()"><i data-lucide="refresh-cw"></i> Réinitialiser</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Right Column -->
      <div class="col-4">
        <!-- App Preferences -->
        <div class="card mb-4">
          <div class="card-header"><span class="card-title"><i data-lucide="sliders"></i> Préférences</span></div>
          <div class="card-body">
            <div class="settings-row">
              <div class="settings-row-label">
                <strong>Mode sombre</strong>
                <span>Basculer entre thème sombre et clair</span>
              </div>
              <label class="toggle">
                <input type="checkbox" id="s-dark-mode" ${document.documentElement.getAttribute('data-theme')==='dark'?'checked':''} onchange="toggleTheme()" />
                <span class="toggle-slider"></span>
              </label>
            </div>
            <div class="settings-row">
              <div class="settings-row-label">
                <strong>Notifications</strong>
                <span>Afficher les alertes dans l'application</span>
              </div>
              <label class="toggle">
                <input type="checkbox" id="s-notif" ${settings.notifications!==false?'checked':''} onchange="toggleNotifications()" />
                <span class="toggle-slider"></span>
              </label>
            </div>
            <div class="settings-row">
              <div class="settings-row-label">
                <strong>Sauvegarde auto</strong>
                <span>Sauvegarder automatiquement les données</span>
              </div>
              <label class="toggle">
                <input type="checkbox" id="s-auto-backup" ${settings.autoBackup?'checked':''} onchange="toggleAutoBackup()" />
                <span class="toggle-slider"></span>
              </label>
            </div>
          </div>
        </div>

        <!-- App Info -->
        <div class="card mb-4">
          <div class="card-header"><span class="card-title"><i data-lucide="info"></i> À propos</span></div>
          <div class="card-body">
            <div style="text-align:center;padding:16px 0">
              <div class="logo-icon" style="width:56px;height:56px;border-radius:14px;margin:0 auto 12px">
                <svg width="32" height="32" viewBox="0 0 48 48" fill="none">
                  <path d="M8 32L4 36H44L40 32H8Z" fill="#00C9A7"/>
                  <path d="M10 24H38L40 32H8L10 24Z" fill="#00C9A7" opacity="0.8"/>
                  <path d="M14 16H34L38 24H10L14 16Z" fill="#00C9A7" opacity="0.6"/>
                  <circle cx="13" cy="36" r="4" fill="#6366F1"/>
                  <circle cx="35" cy="36" r="4" fill="#6366F1"/>
                </svg>
              </div>
              <div style="font-size:1.5rem;font-weight:900;letter-spacing:-1px">FLOTTE <span style="color:var(--accent)">2.0</span></div>
              <div style="font-size:0.8rem;color:var(--text-muted);margin-top:4px">CRM Gestion de Flotte</div>
              <div style="font-size:0.72rem;color:var(--text-muted);margin-top:8px">Version ${FLOTTE.version}</div>
            </div>
            <div class="divider"></div>
            <div style="font-size:0.78rem;color:var(--text-secondary);display:flex;flex-direction:column;gap:8px">
              <div class="flex justify-between"><span>Véhicules</span><strong>${DB.vehicles().length}</strong></div>
              <div class="flex justify-between"><span>Conducteurs</span><strong>${DB.drivers().length}</strong></div>
              <div class="flex justify-between"><span>Versements</span><strong>${DB.payments().length}</strong></div>
              <div class="flex justify-between"><span>Dépenses</span><strong>${DB.expenses().length}</strong></div>
              <div class="flex justify-between"><span>Alertes actives</span><strong>${Stats.unresolvedAlerts()}</strong></div>
            </div>
          </div>
        </div>

        <!-- Quick Stats -->
        <div class="card">
          <div class="card-header"><span class="card-title"><i data-lucide="activity"></i> Performance globale</span></div>
          <div class="card-body">
            <div class="gauge-container">
              <div class="chart-container" style="height:160px;width:160px;position:relative">
                <canvas id="settings-gauge-chart"></canvas>
                <div class="gauge-label">
                  <div class="gauge-value" id="gauge-value-text">—</div>
                  <div class="gauge-unit">rentabilité</div>
                </div>
              </div>
            </div>
            <div class="divider"></div>
            <div style="font-size:0.78rem;color:var(--text-secondary);display:flex;flex-direction:column;gap:6px">
              <div class="flex justify-between"><span>CA mensuel</span><strong class="text-accent">${fmtCurrency(Stats.totalRevenue(30))}</strong></div>
              <div class="flex justify-between"><span>Dépenses</span><strong class="text-danger">${fmtCurrency(Stats.totalExpenses(30))}</strong></div>
              <div class="flex justify-between"><span>Bénéfice net</span><strong class="${Stats.netProfit(30)>=0?'text-success':'text-danger'}">${fmtCurrency(Stats.netProfit(30))}</strong></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  document.getElementById('page-content').innerHTML = html;
  lucide.createIcons();

  setTimeout(() => {
    const rev = Stats.totalRevenue(30);
    const net = Stats.netProfit(30);
    const rentab = rev > 0 ? Math.round(net/rev*100) : 0;
    const gaugeEl = document.getElementById('gauge-value-text');
    if (gaugeEl) gaugeEl.textContent = rentab + '%';
    renderGaugeChart(rentab);
  }, 60);
}

function saveCompanySettings() {
  const settings = DB.settings();
  settings.company = {
    name: document.getElementById('s-company-name')?.value || '',
    phone: document.getElementById('s-company-phone')?.value || '',
    email: document.getElementById('s-company-email')?.value || '',
    address: document.getElementById('s-company-address')?.value || '',
    rib: document.getElementById('s-company-rib')?.value || '',
    currency: document.getElementById('s-currency')?.value || 'FCFA',
  };
  DB.saveSettings(settings);
  showToast('success', 'Sauvegardé', 'Informations de la société mises à jour');
}

function toggleTheme() {
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  const newTheme = isDark ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', newTheme);
  const settings = DB.settings();
  settings.theme = newTheme;
  DB.saveSettings(settings);
  const themeIcon = document.querySelector('#theme-toggle i');
  if (themeIcon) { themeIcon.setAttribute('data-lucide', newTheme === 'dark' ? 'sun' : 'moon'); lucide.createIcons(); }
}

function toggleNotifications() {
  const settings = DB.settings();
  settings.notifications = document.getElementById('s-notif')?.checked;
  DB.saveSettings(settings);
  showToast('info', 'Paramètre', `Notifications ${settings.notifications ? 'activées' : 'désactivées'}`);
}

function toggleAutoBackup() {
  const settings = DB.settings();
  settings.autoBackup = document.getElementById('s-auto-backup')?.checked;
  DB.saveSettings(settings);
  showToast('info', 'Paramètre', `Sauvegarde auto ${settings.autoBackup ? 'activée' : 'désactivée'}`);
}

function exportAllData() {
  const data = {
    version: FLOTTE.version,
    exportDate: new Date().toISOString(),
    vehicles: DB.vehicles(),
    drivers: DB.drivers(),
    payments: DB.payments(),
    expenses: DB.expenses(),
    alerts: DB.alerts(),
    trips: DB.trips(),
    settings: DB.settings(),
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `flotte2_backup_${today()}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('success', 'Exporté', 'Backup JSON téléchargé');
}

function importData() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json';
  input.onchange = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const data = JSON.parse(ev.target.result);
        if (data.vehicles) DB.saveVehicles(data.vehicles);
        if (data.drivers)  DB.saveDrivers(data.drivers);
        if (data.payments) DB.savePayments(data.payments);
        if (data.expenses) DB.saveExpenses(data.expenses);
        if (data.alerts)   DB.saveAlerts(data.alerts);
        if (data.trips)    DB.saveTrips(data.trips);
        showToast('success', 'Importé', 'Données restaurées avec succès');
        App.navigate(App.currentPage);
        updateBadges();
      } catch {
        showToast('error', 'Erreur', 'Fichier JSON invalide');
      }
    };
    reader.readAsText(file);
  };
  input.click();
}

function resetToSeedData() {
  openModal('Réinitialisation',
    `<div class="info-box info-danger"><i data-lucide="alert-triangle"></i><span>Toutes les données actuelles seront <strong>remplacées</strong> par les données de démonstration. Cette action est <strong>irréversible</strong>.</span></div>`,
    [
      { label: 'Annuler', cls: 'btn-outline', action: closeModal },
      { label: '⚠️ Réinitialiser', cls: 'btn-danger', action: () => {
        DB.saveVehicles(SEED_VEHICLES);
        DB.saveDrivers(SEED_DRIVERS);
        DB.savePayments(SEED_PAYMENTS);
        DB.saveExpenses(SEED_EXPENSES);
        DB.saveAlerts(SEED_ALERTS);
        DB.saveTrips(SEED_TRIPS);
        showToast('success', 'Réinitialisé', 'Données de démonstration chargées');
        closeModal();
        App.navigate('dashboard');
        updateBadges();
      }}
    ]
  );
}

function openAddUserModal() {
  const body = `<div class="info-box info-accent" style="margin-bottom:16px"><i data-lucide="info"></i><span>La gestion multi-utilisateurs complète est disponible dans la version Pro de FLOTTE 2.0.</span></div>
  <div class="form-row">
    <div class="form-group"><label class="form-label">Nom</label><input class="form-control" placeholder="Nom de l'utilisateur" /></div>
    <div class="form-group"><label class="form-label">Email</label><input class="form-control" type="email" placeholder="email@exemple.com" /></div>
  </div>
  <div class="form-group">
    <label class="form-label">Rôle</label>
    <select class="form-control">
      <option>Gestionnaire</option>
      <option>Comptable</option>
      <option>Superviseur</option>
      <option>Lecture seule</option>
    </select>
  </div>`;

  openModal('Ajouter un utilisateur', body, [
    { label: 'Annuler', cls: 'btn-outline', action: closeModal },
    { label: 'Passer en Pro', cls: 'btn-primary', action: () => { showToast('info','Pro','Contactez-nous pour activer la version Pro'); closeModal(); } }
  ]);
}
