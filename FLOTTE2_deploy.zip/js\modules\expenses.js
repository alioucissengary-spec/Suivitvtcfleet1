/* ============================================================
   FLOTTE 2.0 — Expenses Module
   ============================================================ */

let expenseFilter = { search: '', category: '', vehicleId: '' };

function renderExpenses() {
  const expenses = DB.expenses();
  const catTotals = Stats.expensesByCategory();
  const grandTotal = Object.values(catTotals).reduce((s,v)=>s+v,0);

  const html = `
    <div class="page-header">
      <div class="page-header-left">
        <h1>Gestion des Dépenses</h1>
        <p class="page-subtitle">Suivi et analyse des dépenses par catégorie</p>
      </div>
      <div class="page-actions">
        <button class="btn btn-outline btn-sm" onclick="exportExpensesCSV()"><i data-lucide="download"></i> Exporter</button>
        <button class="btn btn-primary" onclick="openExpenseModal()"><i data-lucide="plus"></i> Nouvelle dépense</button>
      </div>
    </div>

    <!-- KPIs -->
    <div class="kpi-grid" style="margin-bottom:var(--space-5)">
      <div class="kpi-card danger">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--danger-light);color:var(--danger)"><i data-lucide="receipt"></i></div></div>
        <div class="kpi-value">${fmtNum(Math.round(grandTotal/1000))}k</div>
        <div class="kpi-label">Total dépenses</div>
        <div class="kpi-sublabel">${expenses.length} transactions</div>
      </div>
      <div class="kpi-card warning">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--warning-light);color:var(--warning)"><i data-lucide="fuel"></i></div></div>
        <div class="kpi-value">${fmtNum(Math.round(catTotals.fuel/1000))}k</div>
        <div class="kpi-label">Carburant</div>
        <div class="kpi-sublabel">${grandTotal>0?Math.round(catTotals.fuel/grandTotal*100):0}% du total</div>
      </div>
      <div class="kpi-card info">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--info-light);color:var(--info)"><i data-lucide="wrench"></i></div></div>
        <div class="kpi-value">${fmtNum(Math.round(catTotals.maintenance/1000))}k</div>
        <div class="kpi-label">Maintenance</div>
        <div class="kpi-sublabel">${grandTotal>0?Math.round(catTotals.maintenance/grandTotal*100):0}% du total</div>
      </div>
      <div class="kpi-card secondary">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--secondary-light);color:var(--secondary)"><i data-lucide="shield"></i></div></div>
        <div class="kpi-value">${fmtNum(Math.round(catTotals.insurance/1000))}k</div>
        <div class="kpi-label">Assurances</div>
        <div class="kpi-sublabel">${grandTotal>0?Math.round(catTotals.insurance/grandTotal*100):0}% du total</div>
      </div>
    </div>

    <div class="grid-12 mb-6">
      <!-- Category Breakdown -->
      <div class="card col-4">
        <div class="card-header"><span class="card-title"><i data-lucide="pie-chart"></i> Répartition</span></div>
        <div class="card-body">
          <div class="chart-container" style="height:200px;margin-bottom:16px">
            <canvas id="chart-expense-cat"></canvas>
          </div>
          <div class="expense-category-bar">
            ${[
              { key:'fuel', label:'Carburant', color:'var(--warning)' },
              { key:'maintenance', label:'Maintenance', color:'var(--info)' },
              { key:'insurance', label:'Assurance', color:'var(--secondary)' },
              { key:'fine', label:'Amendes', color:'var(--danger)' },
              { key:'other', label:'Autres', color:'var(--text-muted)' },
            ].map(cat => {
              const pct = grandTotal > 0 ? Math.round(catTotals[cat.key]/grandTotal*100) : 0;
              return `<div class="expense-cat-row">
                <span class="expense-cat-label">${cat.label}</span>
                <div class="expense-cat-bar"><div class="expense-cat-fill" style="width:${pct}%;background:${cat.color}"></div></div>
                <span class="expense-cat-amount">${fmtNum(Math.round(catTotals[cat.key]/1000))}k</span>
              </div>`;
            }).join('')}
          </div>
        </div>
      </div>

      <!-- Expense Per Vehicle -->
      <div class="card col-8">
        <div class="card-header"><span class="card-title"><i data-lucide="bar-chart-2"></i> Dépenses par véhicule</span></div>
        <div class="card-body">
          <div class="chart-container" style="height:280px">
            <canvas id="chart-expense-vehicle"></canvas>
          </div>
        </div>
      </div>
    </div>

    <!-- Filters & Table -->
    <div class="card">
      <div class="card-header">
        <span class="card-title"><i data-lucide="list"></i> Détail des dépenses</span>
        <div class="card-actions">
          <div class="search-box" style="max-width:220px">
            <i data-lucide="search"></i>
            <input type="text" placeholder="Description..." id="exp-search" oninput="filterExpenses()" value="${expenseFilter.search}" />
          </div>
          <select class="filter-select" id="exp-cat-filter" onchange="filterExpenses()">
            <option value="">Toutes catégories</option>
            <option value="fuel">Carburant</option>
            <option value="maintenance">Maintenance</option>
            <option value="insurance">Assurance</option>
            <option value="fine">Amende</option>
            <option value="other">Autre</option>
          </select>
          <select class="filter-select" id="exp-vehicle-filter" onchange="filterExpenses()">
            <option value="">Tous véhicules</option>
            ${DB.vehicles().map(v=>`<option value="${v.id}">${v.plate}</option>`).join('')}
          </select>
        </div>
      </div>
      <div id="expenses-table-container"></div>
    </div>
  `;

  document.getElementById('page-content').innerHTML = html;
  lucide.createIcons();
  renderExpensesTable();
  setTimeout(() => {
    renderExpenseCategoryChart(catTotals);
    renderExpenseVehicleChart();
  }, 60);
}

function renderExpensesTable() {
  const catLabel = { fuel:'Carburant', maintenance:'Maintenance', insurance:'Assurance', fine:'Amende', other:'Autre' };
  const catCls   = { fuel:'cat-fuel', maintenance:'cat-maintenance', insurance:'cat-insurance', fine:'cat-fine', other:'cat-other' };
  const catIcon  = { fuel:'fuel', maintenance:'wrench', insurance:'shield', fine:'alert-triangle', other:'package' };

  const filtered = DB.expenses().filter(e => {
    const q = expenseFilter.search.toLowerCase();
    const matchS = !q || e.description.toLowerCase().includes(q) || e.reference.toLowerCase().includes(q);
    const matchC = !expenseFilter.category || e.category === expenseFilter.category;
    const matchV = !expenseFilter.vehicleId || e.vehicleId === expenseFilter.vehicleId;
    return matchS && matchC && matchV;
  }).sort((a,b) => b.date.localeCompare(a.date));

  const container = document.getElementById('expenses-table-container');
  if (!container) return;

  container.innerHTML = `<div class="table-wrapper" style="border:none;border-radius:0">
    <table class="table">
      <thead><tr><th>Catégorie</th><th>Description</th><th>Véhicule</th><th>Montant</th><th>Date</th><th>Payé par</th><th>Réf.</th><th>Actions</th></tr></thead>
      <tbody>
        ${filtered.length === 0 ? `<tr><td colspan="8" style="text-align:center;padding:40px;color:var(--text-muted)">Aucune dépense trouvée</td></tr>` :
          filtered.map(e => {
            const v = Stats.vehicleById(e.vehicleId);
            return `<tr>
              <td>
                <div style="display:flex;align-items:center;gap:8px">
                  <div class="cat-icon ${catCls[e.category]||'cat-other'}"><i data-lucide="${catIcon[e.category]||'package'}"></i></div>
                  <span style="font-size:0.82rem">${catLabel[e.category]||e.category}</span>
                </div>
              </td>
              <td>
                <div style="font-weight:500;font-size:0.875rem">${e.description}</div>
                ${e.notes?`<div class="text-xs text-muted">${e.notes}</div>`:''}
              </td>
              <td><code class="font-mono text-sm">${v?v.plate:'—'}</code></td>
              <td><strong class="font-mono text-danger">${fmtCurrency(e.amount)}</strong></td>
              <td class="text-muted text-sm">${fmtDateShort(e.date)}</td>
              <td><span class="badge badge-muted">${e.paidBy}</span></td>
              <td class="text-xs text-muted">${e.reference||'—'}</td>
              <td>
                <div class="table-actions">
                  <button class="btn btn-icon btn-ghost btn-sm" onclick="openExpenseModal('${e.id}')" title="Modifier"><i data-lucide="pencil"></i></button>
                  <button class="btn btn-icon btn-ghost btn-sm" onclick="deleteExpense('${e.id}')" title="Supprimer" style="color:var(--danger)"><i data-lucide="trash-2"></i></button>
                </div>
              </td>
            </tr>`;
          }).join('')}
      </tbody>
    </table>
  </div>`;
  lucide.createIcons();
}

function filterExpenses() {
  expenseFilter.search    = document.getElementById('exp-search')?.value || '';
  expenseFilter.category  = document.getElementById('exp-cat-filter')?.value || '';
  expenseFilter.vehicleId = document.getElementById('exp-vehicle-filter')?.value || '';
  renderExpensesTable();
}

function openExpenseModal(id = null) {
  const e = id ? DB.expenses().find(x=>x.id===id) : null;
  const body = `<form id="expense-form">
    <div class="form-row">
      <div class="form-group">
        <label class="form-label required">Catégorie</label>
        <select class="form-control" id="ef-cat" required>
          <option value="fuel" ${e?.category==='fuel'?'selected':''}>⛽ Carburant</option>
          <option value="maintenance" ${e?.category==='maintenance'?'selected':''}>🔧 Maintenance</option>
          <option value="insurance" ${e?.category==='insurance'?'selected':''}>🛡️ Assurance</option>
          <option value="fine" ${e?.category==='fine'?'selected':''}>⚠️ Amende</option>
          <option value="other" ${e?.category==='other'?'selected':''}>📦 Autre</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label required">Véhicule</label>
        <select class="form-control" id="ef-vehicle" required>
          <option value="">— Sélectionner —</option>
          ${DB.vehicles().map(v=>`<option value="${v.id}" ${e?.vehicleId===v.id?'selected':''}>${v.plate} — ${v.brand} ${v.model}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label required">Montant (FCFA)</label>
        <input class="form-control" id="ef-amount" type="number" min="0" value="${e?.amount||0}" required />
      </div>
      <div class="form-group">
        <label class="form-label required">Date</label>
        <input class="form-control" id="ef-date" type="date" value="${e?.date||today()}" required />
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label required">Description</label>
        <input class="form-control" id="ef-desc" placeholder="Ex: Plein carburant" value="${e?.description||''}" required />
      </div>
      <div class="form-group">
        <label class="form-label">Référence / Facture</label>
        <input class="form-control" id="ef-ref" placeholder="FAC-2026-001" value="${e?.reference||''}" />
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Payé par</label>
        <select class="form-control" id="ef-paid">
          ${['Caisse','Virement','Chèque','Mobile Money'].map(x=>`<option ${e?.paidBy===x?'selected':''}>${x}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Notes</label>
      <textarea class="form-control" id="ef-notes" rows="2">${e?.notes||''}</textarea>
    </div>
  </form>`;

  openModal(e ? 'Modifier la dépense' : 'Nouvelle dépense', body, [
    { label: 'Annuler', cls: 'btn-outline', action: closeModal },
    { label: e ? 'Mettre à jour' : 'Enregistrer', cls: 'btn-primary', action: () => saveExpense(id) }
  ]);
}

function saveExpense(id) {
  const category  = document.getElementById('ef-cat')?.value;
  const vehicleId = document.getElementById('ef-vehicle')?.value;
  const amount    = +document.getElementById('ef-amount')?.value;
  const date      = document.getElementById('ef-date')?.value;
  const description = document.getElementById('ef-desc')?.value.trim();
  if (!category || !vehicleId || !amount || !date || !description) { showToast('error','Erreur','Champs obligatoires manquants'); return; }

  const data = { category, vehicleId, amount, date, description,
    reference: document.getElementById('ef-ref').value,
    paidBy: document.getElementById('ef-paid').value,
    notes: document.getElementById('ef-notes').value,
  };

  const expenses = DB.expenses();
  if (id) {
    const idx = expenses.findIndex(e=>e.id===id);
    if (idx>-1) expenses[idx] = { ...expenses[idx], ...data };
    showToast('success','Mis à jour','Dépense modifiée');
  } else {
    expenses.push({ id: uid(), ...data });
    showToast('success','Enregistrée',`Dépense de ${fmtCurrency(amount)} enregistrée`);
  }
  DB.saveExpenses(expenses);
  closeModal();
  renderExpenses();
}

function deleteExpense(id) {
  DB.saveExpenses(DB.expenses().filter(e=>e.id!==id));
  showToast('success','Supprimée','Dépense supprimée');
  renderExpensesTable();
}

function exportExpensesCSV() {
  const catLabel = { fuel:'Carburant', maintenance:'Maintenance', insurance:'Assurance', fine:'Amende', other:'Autre' };
  const rows = [['Date','Catégorie','Description','Véhicule','Montant','Payé par','Référence','Notes']];
  DB.expenses().sort((a,b)=>b.date.localeCompare(a.date)).forEach(e => {
    const v = Stats.vehicleById(e.vehicleId);
    rows.push([e.date, catLabel[e.category]||e.category, e.description, v?v.plate:'', e.amount, e.paidBy, e.reference, e.notes]);
  });
  downloadCSV(rows,'depenses_flotte2.csv');
}
