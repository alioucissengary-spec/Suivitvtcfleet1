/* ============================================================
   FLOTTE 2.0 — Data Layer & Mock State Management
   ============================================================ */

const FLOTTE = {
  version: '2.0.0',
  company: {
    name: 'Transport Express SARL',
    logo: '',
    phone: '+221 77 000 00 00',
    email: 'contact@transport-express.sn',
    address: 'Dakar, Sénégal',
    rib: 'SN002-00001-01234567890-02',
    currency: 'FCFA',
  },
};

/* -------- Helpers -------- */
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
function fmtCurrency(n) {
  return new Intl.NumberFormat('fr-FR').format(Math.round(n)) + ' FCFA';
}
function fmtNum(n) {
  return new Intl.NumberFormat('fr-FR').format(n);
}
function fmtDate(d) {
  return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
}
function fmtDateShort(d) {
  return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
}
function today() {
  return new Date().toISOString().split('T')[0];
}
function daysFromNow(d) {
  return Math.ceil((new Date(d) - new Date()) / 86400000);
}
function randomBetween(a, b) {
  return Math.floor(Math.random() * (b - a + 1)) + a;
}
function initials(name) {
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
}

/* -------- Default Seed Data -------- */
const SEED_VEHICLES = [
  { id: 'v001', plate: 'DK-4521-AB', brand: 'Toyota', model: 'Hiace', year: 2020, type: 'minibus', color: 'Blanc', fuel: 'Diesel', seats: 18, km: 142500, status: 'active', driverId: 'd001', purchaseDate: '2020-03-15', purchasePrice: 12500000, insuranceExpiry: '2026-06-30', nextMaintenance: '2026-05-10', dailyTarget: 35000, notes: '' },
  { id: 'v002', plate: 'DK-7834-CD', brand: 'Mercedes', model: 'Sprinter', year: 2019, type: 'minibus', color: 'Gris', fuel: 'Diesel', seats: 22, km: 198000, status: 'active', driverId: 'd002', purchaseDate: '2019-07-20', purchasePrice: 18000000, insuranceExpiry: '2026-08-15', nextMaintenance: '2026-04-28', dailyTarget: 40000, notes: '' },
  { id: 'v003', plate: 'DK-2210-EF', brand: 'Hyundai', model: 'H350', year: 2021, type: 'minibus', color: 'Bleu', fuel: 'Diesel', seats: 15, km: 87300, status: 'maintenance', driverId: null, purchaseDate: '2021-01-10', purchasePrice: 14000000, insuranceExpiry: '2026-12-31', nextMaintenance: '2026-04-26', dailyTarget: 30000, notes: 'Vidange + freins en cours' },
  { id: 'v004', plate: 'DK-6609-GH', brand: 'Ford', model: 'Transit', year: 2022, type: 'van', color: 'Blanc', fuel: 'Diesel', seats: 9, km: 54200, status: 'active', driverId: 'd003', purchaseDate: '2022-05-05', purchasePrice: 9500000, insuranceExpiry: '2026-05-04', nextMaintenance: '2026-07-01', dailyTarget: 25000, notes: '' },
  { id: 'v005', plate: 'DK-9901-IJ', brand: 'Renault', model: 'Master', year: 2018, type: 'van', color: 'Rouge', fuel: 'Diesel', seats: 12, km: 267000, status: 'inactive', driverId: null, purchaseDate: '2018-11-22', purchasePrice: 8000000, insuranceExpiry: '2025-11-21', nextMaintenance: '2026-06-15', dailyTarget: 20000, notes: 'Hors service - moteur' },
  { id: 'v006', plate: 'DK-3345-KL', brand: 'Toyota', model: 'Coaster', year: 2023, type: 'bus', color: 'Jaune', fuel: 'Diesel', seats: 30, km: 31000, status: 'active', driverId: 'd004', purchaseDate: '2023-08-01', purchasePrice: 22000000, insuranceExpiry: '2027-07-31', nextMaintenance: '2026-09-01', dailyTarget: 60000, notes: '' },
];

const SEED_DRIVERS = [
  { id: 'd001', firstName: 'Mamadou', lastName: 'Diallo', phone: '+221 77 123 4567', email: 'mamadou.diallo@email.com', licenseNo: 'SEN-2018-004521', licenseExpiry: '2028-03-15', contract: 'CDI', salary: 180000, startDate: '2020-04-01', status: 'active', vehicleId: 'v001', totalTrips: 847, totalKm: 125400, rating: 4.7, notes: '' },
  { id: 'd002', firstName: 'Oumar', lastName: 'Sow', phone: '+221 76 234 5678', email: 'oumar.sow@email.com', licenseNo: 'SEN-2016-002134', licenseExpiry: '2026-07-20', contract: 'CDI', salary: 200000, startDate: '2019-08-01', status: 'active', vehicleId: 'v002', totalTrips: 1203, totalKm: 189600, rating: 4.5, notes: '' },
  { id: 'd003', firstName: 'Ibrahima', lastName: 'Fall', phone: '+221 78 345 6789', email: 'ibrahima.fall@email.com', licenseNo: 'SEN-2020-007890', licenseExpiry: '2027-10-05', contract: 'CDD', salary: 150000, startDate: '2022-06-01', status: 'active', vehicleId: 'v004', totalTrips: 412, totalKm: 48200, rating: 4.8, notes: '' },
  { id: 'd004', firstName: 'Cheikh', lastName: 'Ndiaye', phone: '+221 70 456 7890', email: 'cheikh.ndiaye@email.com', licenseNo: 'SEN-2019-005678', licenseExpiry: '2029-02-28', contract: 'CDI', salary: 250000, startDate: '2023-09-01', status: 'active', vehicleId: 'v006', totalTrips: 234, totalKm: 28700, rating: 4.9, notes: '' },
  { id: 'd005', firstName: 'Fatou', lastName: 'Mbaye', phone: '+221 77 567 8901', email: 'fatou.mbaye@email.com', licenseNo: 'SEN-2021-009012', licenseExpiry: '2031-05-15', contract: 'Intérimaire', salary: 120000, startDate: '2024-01-15', status: 'inactive', vehicleId: null, totalTrips: 98, totalKm: 12500, rating: 4.3, notes: 'En congé' },
];

const SEED_EXPENSES = [
  { id: 'e001', vehicleId: 'v001', category: 'fuel', amount: 85000, date: '2026-04-25', description: 'Plein carburant', reference: 'REF-001', paidBy: 'Caisse', notes: '' },
  { id: 'e002', vehicleId: 'v002', category: 'maintenance', amount: 250000, date: '2026-04-24', description: 'Vidange moteur + filtres', reference: 'FAC-2024-089', paidBy: 'Virement', notes: 'Garage Modou Auto' },
  { id: 'e003', vehicleId: 'v003', category: 'maintenance', amount: 380000, date: '2026-04-26', description: 'Remplacement plaquettes freins avant', reference: 'FAC-2024-092', paidBy: 'Chèque', notes: '' },
  { id: 'e004', vehicleId: 'v001', category: 'fuel', amount: 78000, date: '2026-04-23', description: 'Plein carburant', reference: 'REF-002', paidBy: 'Caisse', notes: '' },
  { id: 'e005', vehicleId: 'v004', category: 'insurance', amount: 420000, date: '2026-04-20', description: 'Prime assurance annuelle', reference: 'ASS-2026-044', paidBy: 'Virement', notes: 'Compagnie AXA' },
  { id: 'e006', vehicleId: 'v002', category: 'fuel', amount: 92000, date: '2026-04-22', description: 'Plein carburant', reference: 'REF-003', paidBy: 'Caisse', notes: '' },
  { id: 'e007', vehicleId: 'v006', category: 'fuel', amount: 145000, date: '2026-04-21', description: 'Plein carburant', reference: 'REF-004', paidBy: 'Caisse', notes: '' },
  { id: 'e008', vehicleId: 'v005', category: 'maintenance', amount: 1200000, date: '2026-04-18', description: 'Révision moteur complète', reference: 'FAC-2024-080', paidBy: 'Virement', notes: 'Atelier central' },
  { id: 'e009', vehicleId: 'v001', category: 'fine', amount: 15000, date: '2026-04-15', description: 'Amende stationnement', reference: 'AM-2026-112', paidBy: 'Caisse', notes: '' },
  { id: 'e010', vehicleId: 'v004', category: 'fuel', amount: 67000, date: '2026-04-19', description: 'Plein carburant', reference: 'REF-005', paidBy: 'Caisse', notes: '' },
  { id: 'e011', vehicleId: 'v006', category: 'maintenance', amount: 95000, date: '2026-04-10', description: 'Changement pneu arrière', reference: 'FAC-2024-075', paidBy: 'Chèque', notes: '' },
  { id: 'e012', vehicleId: 'v002', category: 'other', amount: 35000, date: '2026-04-08', description: 'Lavage + nettoyage intérieur', reference: '', paidBy: 'Caisse', notes: '' },
];

const SEED_PAYMENTS = [
  { id: 'p001', driverId: 'd001', vehicleId: 'v001', amount: 35000, date: '2026-04-26', period: 'Journalier', method: 'Espèces', status: 'paid', notes: '' },
  { id: 'p002', driverId: 'd002', vehicleId: 'v002', amount: 40000, date: '2026-04-26', period: 'Journalier', method: 'Espèces', status: 'paid', notes: '' },
  { id: 'p003', driverId: 'd003', vehicleId: 'v004', amount: 28000, date: '2026-04-26', period: 'Journalier', method: 'Espèces', status: 'pending', notes: '' },
  { id: 'p004', driverId: 'd004', vehicleId: 'v006', amount: 60000, date: '2026-04-26', period: 'Journalier', method: 'Mobile Money', status: 'paid', notes: '' },
  { id: 'p005', driverId: 'd001', vehicleId: 'v001', amount: 35000, date: '2026-04-25', period: 'Journalier', method: 'Espèces', status: 'paid', notes: '' },
  { id: 'p006', driverId: 'd002', vehicleId: 'v002', amount: 40000, date: '2026-04-25', period: 'Journalier', method: 'Espèces', status: 'paid', notes: '' },
  { id: 'p007', driverId: 'd003', vehicleId: 'v004', amount: 25000, date: '2026-04-25', period: 'Journalier', method: 'Espèces', status: 'paid', notes: '' },
  { id: 'p008', driverId: 'd004', vehicleId: 'v006', amount: 60000, date: '2026-04-25', period: 'Journalier', method: 'Mobile Money', status: 'paid', notes: '' },
  { id: 'p009', driverId: 'd001', vehicleId: 'v001', amount: 35000, date: '2026-04-24', period: 'Journalier', method: 'Espèces', status: 'paid', notes: '' },
  { id: 'p010', driverId: 'd002', vehicleId: 'v002', amount: 40000, date: '2026-04-24', period: 'Journalier', method: 'Espèces', status: 'late', notes: 'Versement en retard' },
  { id: 'p011', driverId: 'd003', vehicleId: 'v004', amount: 25000, date: '2026-04-24', period: 'Journalier', method: 'Espèces', status: 'paid', notes: '' },
  { id: 'p012', driverId: 'd004', vehicleId: 'v006', amount: 60000, date: '2026-04-24', period: 'Journalier', method: 'Mobile Money', status: 'paid', notes: '' },
  { id: 'p013', driverId: 'd001', vehicleId: 'v001', amount: 35000, date: '2026-04-23', period: 'Journalier', method: 'Espèces', status: 'paid', notes: '' },
  { id: 'p014', driverId: 'd002', vehicleId: 'v002', amount: 40000, date: '2026-04-23', period: 'Journalier', method: 'Espèces', status: 'paid', notes: '' },
  { id: 'p015', driverId: 'd003', vehicleId: 'v004', amount: 25000, date: '2026-04-22', period: 'Journalier', method: 'Espèces', status: 'late', notes: '' },
];

const SEED_ALERTS = [
  { id: 'a001', type: 'maintenance', severity: 'critical', vehicleId: 'v002', title: 'Maintenance urgente requise', description: 'DK-7834-CD: Prochaine maintenance dépassée de 2 jours', date: today(), resolved: false },
  { id: 'a002', type: 'insurance', severity: 'warning', vehicleId: 'v004', title: 'Assurance expire bientôt', description: 'DK-6609-GH: Assurance expire dans 8 jours (04/05/2026)', date: today(), resolved: false },
  { id: 'a003', type: 'payment', severity: 'warning', vehicleId: 'v002', title: 'Versement en retard', description: 'Oumar Sow — Versement du 24/04 non régularisé', date: today(), resolved: false },
  { id: 'a004', type: 'license', severity: 'warning', vehicleId: null, title: "Permis de conduire expirant", description: 'Oumar Sow: Permis expire le 20/07/2026 (dans 85 jours)', date: today(), resolved: false },
  { id: 'a005', type: 'maintenance', severity: 'info', vehicleId: 'v001', title: 'Maintenance planifiée', description: 'DK-4521-AB: Maintenance prévue le 10/05/2026', date: today(), resolved: false },
  { id: 'a006', type: 'vehicle', severity: 'critical', vehicleId: 'v005', title: 'Véhicule hors service', description: 'DK-9901-IJ: Hors service depuis 30 jours — décision requise', date: today(), resolved: false },
];

const SEED_TRIPS = [
  { id: 't001', vehicleId: 'v001', driverId: 'd001', departure: 'Dakar - Plateau', arrival: 'Rufisque', distance: 23, duration: 45, date: '2026-04-26', passengers: 14, status: 'completed' },
  { id: 't002', vehicleId: 'v002', driverId: 'd002', departure: 'Dakar - HLM', arrival: 'Thiès', distance: 68, duration: 90, date: '2026-04-26', passengers: 20, status: 'active' },
  { id: 't003', vehicleId: 'v004', driverId: 'd003', departure: 'Dakar - Parcelles', arrival: 'Guédiawaye', distance: 12, duration: 30, date: '2026-04-26', passengers: 8, status: 'completed' },
  { id: 't004', vehicleId: 'v006', driverId: 'd004', departure: 'Dakar - Centre', arrival: 'Mbour', distance: 74, duration: 95, date: '2026-04-26', passengers: 28, status: 'active' },
];

/* -------- State Storage -------- */
const DB = {
  get(key) {
    try {
      const raw = localStorage.getItem('flotte2_' + key);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  },
  set(key, value) {
    try { localStorage.setItem('flotte2_' + key, JSON.stringify(value)); } catch {}
  },
  init() {
    if (!this.get('vehicles')) this.set('vehicles', SEED_VEHICLES);
    if (!this.get('drivers'))  this.set('drivers',  SEED_DRIVERS);
    if (!this.get('expenses')) this.set('expenses', SEED_EXPENSES);
    if (!this.get('payments')) this.set('payments', SEED_PAYMENTS);
    if (!this.get('alerts'))   this.set('alerts',   SEED_ALERTS);
    if (!this.get('trips'))    this.set('trips',     SEED_TRIPS);
    if (!this.get('settings')) this.set('settings', {
      theme: 'dark', currency: 'FCFA', dateFormat: 'fr-FR',
      notifications: true, autoBackup: false,
      company: FLOTTE.company,
    });
  },
  vehicles() { return this.get('vehicles') || []; },
  drivers()  { return this.get('drivers')  || []; },
  expenses() { return this.get('expenses') || []; },
  payments() { return this.get('payments') || []; },
  alerts()   { return this.get('alerts')   || []; },
  trips()    { return this.get('trips')    || []; },
  settings() { return this.get('settings') || {}; },

  saveVehicles(data) { this.set('vehicles', data); },
  saveDrivers(data)  { this.set('drivers',  data); },
  saveExpenses(data) { this.set('expenses', data); },
  savePayments(data) { this.set('payments', data); },
  saveAlerts(data)   { this.set('alerts',   data); },
  saveTrips(data)    { this.set('trips',    data); },
  saveSettings(data) { this.set('settings', data); },
};

/* -------- Computed Stats -------- */
const Stats = {
  totalRevenue(period = 30) {
    const since = new Date();
    since.setDate(since.getDate() - period);
    return DB.payments()
      .filter(p => p.status === 'paid' && new Date(p.date) >= since)
      .reduce((s, p) => s + p.amount, 0);
  },
  totalExpenses(period = 30) {
    const since = new Date();
    since.setDate(since.getDate() - period);
    return DB.expenses()
      .filter(e => new Date(e.date) >= since)
      .reduce((s, e) => s + e.amount, 0);
  },
  netProfit(period = 30) {
    return this.totalRevenue(period) - this.totalExpenses(period);
  },
  activeVehicles() { return DB.vehicles().filter(v => v.status === 'active').length; },
  activeDrivers()  { return DB.drivers().filter(d => d.status === 'active').length; },
  pendingPayments() { return DB.payments().filter(p => p.status === 'pending' || p.status === 'late').length; },
  unresolvedAlerts() { return DB.alerts().filter(a => !a.resolved).length; },
  vehicleById(id) { return DB.vehicles().find(v => v.id === id); },
  driverById(id)  { return DB.drivers().find(d => d.id === id); },
  vehicleRevenue(vehicleId, period = 30) {
    const since = new Date();
    since.setDate(since.getDate() - period);
    return DB.payments()
      .filter(p => p.vehicleId === vehicleId && p.status === 'paid' && new Date(p.date) >= since)
      .reduce((s, p) => s + p.amount, 0);
  },
  vehicleExpenses(vehicleId, period = 30) {
    const since = new Date();
    since.setDate(since.getDate() - period);
    return DB.expenses()
      .filter(e => e.vehicleId === vehicleId && new Date(e.date) >= since)
      .reduce((s, e) => s + e.amount, 0);
  },
  revenueByDay(days = 7) {
    const result = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const rev = DB.payments()
        .filter(p => p.status === 'paid' && p.date === dateStr)
        .reduce((s, p) => s + p.amount, 0);
      const exp = DB.expenses()
        .filter(e => e.date === dateStr)
        .reduce((s, e) => s + e.amount, 0);
      result.push({ date: dateStr, label: d.toLocaleDateString('fr-FR', { weekday: 'short', day: '2-digit' }), revenue: rev, expenses: exp });
    }
    return result;
  },
  expensesByCategory() {
    const cats = { fuel: 0, maintenance: 0, insurance: 0, fine: 0, other: 0 };
    DB.expenses().forEach(e => { if (cats[e.category] !== undefined) cats[e.category] += e.amount; else cats.other += e.amount; });
    return cats;
  },
  vehicleStatusCounts() {
    const counts = { active: 0, maintenance: 0, inactive: 0 };
    DB.vehicles().forEach(v => { if (counts[v.status] !== undefined) counts[v.status]++; });
    return counts;
  },
};
