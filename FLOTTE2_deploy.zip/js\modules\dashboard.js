/* ============================================================
   FLOTTE 2.0 — Dashboard Module
   ============================================================ */

function renderDashboard() {
  const rev = Stats.totalRevenue(30);
  const exp = Stats.totalExpenses(30);
  const net = Stats.netProfit(30);
  const margin = rev > 0 ? Math.round((net / rev) * 100) : 0;
  const statusCounts = Stats.vehicleStatusCounts();
  const dailyData = Stats.revenueByDay(7);
  const recentPayments = DB.payments().sort((a,b) => b.date.localeCompare(a.date)).slice(0, 5);
  const alerts = DB.alerts().filter(a => !a.resolved).slice(0, 4);

  const html = `
    <div class="page-header">
      <div class="page-header-left">
        <h1>Tableau de bord</h1>
        <p class="page-subtitle">Aperçu général de votre flotte — ${fmtDate(today())}</p>
      </div>
      <div class="page-actions">
        <button class="btn btn-outline btn-sm" onclick="exportDashboardPDF()">
          <i data-lucide="download"></i> Exporter
        </button>
        <button class="btn btn-primary btn-sm" onclick="App.navigate('payments'); openPaymentModal()">
          <i data-lucide="plus"></i> Nouveau Versement
        </button>
      </div>
    </div>

    <!-- KPIs -->
    <div class="kpi-grid">
      <div class="kpi-card accent">
        <div class="kpi-header">
          <div class="kpi-icon" style="background:var(--accent-light);color:var(--accent)">
            <i data-lucide="trending-up"></i>
          </div>
          <div class="kpi-trend up"><i data-lucide="arrow-up"></i>+12%</div>
        </div>
        <div class="kpi-value kpi-animate">${fmtNum(Math.round(rev/1000))}k</div>
        <div class="kpi-label">Revenus (30j)</div>
        <div class="kpi-sublabel">${fmtCurrency(rev)}</div>
      </div>
      <div class="kpi-card danger">
        <div class="kpi-header">
          <div class="kpi-icon" style="background:var(--danger-light);color:var(--danger)">
            <i data-lucide="trending-down"></i>
          </div>
          <div class="kpi-trend down"><i data-lucide="arrow-up"></i>+5%</div>
        </div>
        <div class="kpi-value kpi-animate">${fmtNum(Math.round(exp/1000))}k</div>
        <div class="kpi-label">Dépenses (30j)</div>
        <div class="kpi-sublabel">${fmtCurrency(exp)}</div>
      </div>
      <div class="kpi-card ${net >= 0 ? 'success' : 'danger'}">
        <div class="kpi-header">
          <div class="kpi-icon" style="background:var(--success-light);color:var(--success)">
            <i data-lucide="wallet"></i>
          </div>
          <div class="kpi-trend ${margin >= 0 ? 'up' : 'down'}"><i data-lucide="${margin >= 0 ? 'arrow-up' : 'arrow-down'}"></i>${margin}%</div>
        </div>
        <div class="kpi-value kpi-animate">${fmtNum(Math.round(net/1000))}k</div>
        <div class="kpi-label">Bénéfice Net</div>
        <div class="kpi-sublabel">Marge: ${margin}%</div>
      </div>
      <div class="kpi-card secondary">
        <div class="kpi-header">
          <div class="kpi-icon" style="background:var(--secondary-light);color:var(--secondary)">
            <i data-lucide="car"></i>
          </div>
          <div class="kpi-trend neutral">${statusCounts.maintenance} en maint.</div>
        </div>
        <div class="kpi-value kpi-animate">${statusCounts.active}</div>
        <div class="kpi-label">Véhicules actifs</div>
        <div class="kpi-sublabel">/ ${DB.vehicles().length} au total</div>
      </div>
      <div class="kpi-card info">
        <div class="kpi-header">
          <div class="kpi-icon" style="background:var(--info-light);color:var(--info)">
            <i data-lucide="users"></i>
          </div>
          <div class="kpi-trend neutral">${DB.drivers().filter(d=>d.status==='inactive').length} inactif(s)</div>
        </div>
        <div class="kpi-value kpi-animate">${Stats.activeDrivers()}</div>
        <div class="kpi-label">Conducteurs actifs</div>
        <div class="kpi-sublabel">/ ${DB.drivers().length} au total</div>
      </div>
      <div class="kpi-card warning">
        <div class="kpi-header">
          <div class="kpi-icon" style="background:var(--warning-light);color:var(--warning)">
            <i data-lucide="clock"></i>
          </div>
          <div class="kpi-trend ${Stats.pendingPayments() > 0 ? 'down' : 'up'}">${Stats.pendingPayments() > 0 ? 'Action requise' : 'OK'}</div>
        </div>
        <div class="kpi-value kpi-animate">${Stats.pendingPayments()}</div>
        <div class="kpi-label">Versements en attente</div>
        <div class="kpi-sublabel">Journaliers non réglés</div>
      </div>
    </div>

    <!-- Charts & Activity -->
    <div class="grid-12 mb-6">
      <div class="card col-8">
        <div class="card-header">
          <span class="card-title"><i data-lucide="bar-chart-3"></i> Revenus vs Dépenses (7 derniers jours)</span>
          <div class="card-actions">
            <button class="btn btn-ghost btn-sm" onclick="switchChartPeriod(7)" id="chart-btn-7">7j</button>
            <button class="btn btn-ghost btn-sm" onclick="switchChartPeriod(14)" id="chart-btn-14">14j</button>
            <button class="btn btn-ghost btn-sm" onclick="switchChartPeriod(30)" id="chart-btn-30">30j</button>
          </div>
        </div>
        <div class="card-body">
          <div class="chart-container" style="height:260px">
            <canvas id="chart-revenue-expenses"></canvas>
          </div>
        </div>
      </div>
      <div class="card col-4">
        <div class="card-header">
          <span class="card-title"><i data-lucide="pie-chart"></i> Statut Flotte</span>
        </div>
        <div class="card-body" style="display:flex;flex-direction:column;align-items:center;gap:16px;">
          <div class="chart-container" style="height:180px;width:180px">
            <canvas id="chart-fleet-status"></canvas>
          </div>
          <div style="width:100%">
            ${(['active','maintenance','inactive']).map((s,i) => {
              const labels = { active: 'Actifs', maintenance: 'Maintenance', inactive: 'Inactifs' };
              const colors = ['var(--success)', 'var(--warning)', 'var(--danger)'];
              const count = statusCounts[s];
              const pct = DB.vehicles().length > 0 ? Math.round(count / DB.vehicles().length * 100) : 0;
              return `<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;font-size:0.82rem;">
                <div style="width:10px;height:10px;border-radius:50%;background:${colors[i]};flex-shrink:0"></div>
                <span style="flex:1;color:var(--text-secondary)">${labels[s]}</span>
                <strong style="color:var(--text-primary)">${count}</strong>
                <span style="color:var(--text-muted)">(${pct}%)</span>
              </div>`;
            }).join('')}
          </div>
        </div>
      </div>
    </div>

    <div class="grid-12 mb-6">
      <!-- Recent Payments -->
      <div class="card col-8">
        <div class="card-header">
          <span class="card-title"><i data-lucide="banknote"></i> Versements récents</span>
          <button class="btn btn-ghost btn-sm" onclick="App.navigate('payments')">Voir tout <i data-lucide="arrow-right"></i></button>
        </div>
        <div class="table-wrapper" style="border:none;border-radius:0">
          <table class="table">
            <thead>
              <tr>
                <th>Conducteur</th>
                <th>Véhicule</th>
                <th>Montant</th>
                <th>Date</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              ${recentPayments.map(p => {
                const driver = Stats.driverById(p.driverId);
                const vehicle = Stats.vehicleById(p.vehicleId);
                const statusMap = { paid: ['badge-success','Payé'], pending: ['badge-warning','En attente'], late: ['badge-danger','En retard'] };
                const [cls, label] = statusMap[p.status] || ['badge-muted', p.status];
                return `<tr class="payment-row-${p.status}">
                  <td>
                    <div style="display:flex;align-items:center;gap:8px;">
                      <div class="avatar" style="width:28px;height:28px;font-size:0.7rem">${driver ? initials(driver.firstName + ' ' + driver.lastName) : '?'}</div>
                      <span>${driver ? driver.firstName + ' ' + driver.lastName : '—'}</span>
                    </div>
                  </td>
                  <td><code style="font-family:var(--font-mono);font-size:0.8rem;color:var(--text-secondary)">${vehicle ? vehicle.plate : '—'}</code></td>
                  <td><strong style="font-family:var(--font-mono)">${fmtCurrency(p.amount)}</strong></td>
                  <td style="color:var(--text-secondary)">${fmtDateShort(p.date)}</td>
                  <td><span class="badge ${cls}">${label}</span></td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <!-- Alerts -->
      <div class="card col-4">
        <div class="card-header">
          <span class="card-title"><i data-lucide="bell"></i> Alertes actives</span>
          <span class="badge badge-danger">${alerts.length}</span>
        </div>
        <div class="card-body" style="padding:12px">
          ${alerts.length === 0 ? `<div class="empty-state" style="padding:24px"><div class="empty-state-icon"><i data-lucide="check-circle"></i></div><p>Aucune alerte</p></div>` :
            alerts.map(a => {
              const icons = { maintenance: 'wrench', insurance: 'shield', payment: 'banknote', license: 'id-card', vehicle: 'car' };
              const sev = { critical: 'danger', warning: 'warning', info: 'info' };
              const cls = sev[a.severity] || 'info';
              return `<div class="alert-item ${a.severity}" style="margin-bottom:8px;padding:10px 12px;cursor:pointer" onclick="App.navigate('alerts')">
                <div class="alert-icon"><i data-lucide="${icons[a.type] || 'bell'}"></i></div>
                <div class="alert-body">
                  <div class="alert-title" style="font-size:0.82rem">${a.title}</div>
                  <div class="alert-desc" style="font-size:0.74rem">${a.description}</div>
                </div>
              </div>`;
            }).join('')}
          <div style="text-align:center;margin-top:8px">
            <button class="btn-link" onclick="App.navigate('alerts')">Voir toutes les alertes →</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Vehicle Performance -->
    <div class="card mb-6">
      <div class="card-header">
        <span class="card-title"><i data-lucide="gauge"></i> Performance véhicules (30 jours)</span>
        <button class="btn btn-ghost btn-sm" onclick="App.navigate('analytics')">Analyse complète <i data-lucide="arrow-right"></i></button>
      </div>
      <div class="card-body">
        <div class="kpi-grid" style="grid-template-columns:repeat(auto-fill,minmax(200px,1fr))">
          ${DB.vehicles().filter(v => v.status !== 'inactive').map(v => {
            const vRev = Stats.vehicleRevenue(v.id, 30);
            const vExp = Stats.vehicleExpenses(v.id, 30);
            const vNet = vRev - vExp;
            const pct = vRev > 0 ? Math.round(vNet / vRev * 100) : 0;
            const driver = v.driverId ? Stats.driverById(v.driverId) : null;
            return `<div class="kpi-card ${pct >= 50 ? 'success' : pct >= 20 ? 'warning' : 'danger'}" style="cursor:pointer" onclick="App.navigate('vehicles')">
              <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:12px">
                <code style="font-family:var(--font-mono);font-size:0.82rem;font-weight:700;color:var(--text-primary)">${v.plate}</code>
                <span class="badge ${v.status==='active'?'badge-success':v.status==='maintenance'?'badge-warning':'badge-danger'}">${v.status==='active'?'Actif':v.status==='maintenance'?'Maint.':'Inactif'}</span>
              </div>
              <div class="kpi-value" style="font-size:1.2rem">${fmtNum(Math.round(vRev/1000))}k <span style="font-size:0.7rem;color:var(--text-muted)">FCFA</span></div>
              <div class="kpi-label" style="margin-top:4px">Revenus</div>
              <div style="margin-top:8px">
                <div class="progress sm">
                  <div class="progress-bar" style="width:${Math.max(5,Math.min(pct,100))}%;background:${pct>=50?'var(--success)':pct>=20?'var(--warning)':'var(--danger)'}"></div>
                </div>
                <div style="font-size:0.7rem;color:var(--text-muted);margin-top:4px">Rentabilité: ${pct}%</div>
              </div>
              ${driver ? `<div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${driver.firstName} ${driver.lastName}</div>` : ''}
            </div>`;
          }).join('')}
        </div>
      </div>
    </div>
  `;

  document.getElementById('page-content').innerHTML = html;
  lucide.createIcons();

  // Charts
  setTimeout(() => {
    renderRevenueExpensesChart(dailyData);
    renderFleetStatusChart(statusCounts);
  }, 50);
}

function switchChartPeriod(days) {
  const data = Stats.revenueByDay(days);
  renderRevenueExpensesChart(data);
  ['7','14','30'].forEach(d => {
    const btn = document.getElementById('chart-btn-' + d);
    if (btn) btn.className = 'btn btn-ghost btn-sm' + (String(days) === d ? ' btn-primary' : '');
  });
}

function exportDashboardPDF() {
  showToast('info', 'Export', 'Fonctionnalité disponible dans la version Pro');
}
