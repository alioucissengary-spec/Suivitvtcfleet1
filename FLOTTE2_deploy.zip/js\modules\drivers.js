/* ============================================================
   FLOTTE 2.0 — Drivers Module
   ============================================================ */

let driverFilter = { search: '', status: '' };

function renderDrivers() {
  const html = `
    <div class="page-header">
      <div class="page-header-left">
        <h1>Gestion des Conducteurs</h1>
        <p class="page-subtitle">${DB.drivers().length} conducteurs enregistrés</p>
      </div>
      <div class="page-actions">
        <button class="btn btn-outline btn-sm" onclick="exportDriversCSV()"><i data-lucide="download"></i> Exporter</button>
        <button class="btn btn-primary" onclick="openDriverModal()"><i data-lucide="user-plus"></i> Ajouter conducteur</button>
      </div>
    </div>

    <!-- KPIs -->
    <div class="kpi-grid" style="margin-bottom:var(--space-5)">
      ${[
        { label:'Total', val: DB.drivers().length, cls:'secondary', icon:'users' },
        { label:'Actifs', val: DB.drivers().filter(d=>d.status==='active').length, cls:'success', icon:'user-check' },
        { label:'Inactifs', val: DB.drivers().filter(d=>d.status==='inactive').length, cls:'warning', icon:'user-x' },
        { label:'Note moy.', val: (DB.drivers().reduce((s,d)=>s+d.rating,0)/DB.drivers().length||0).toFixed(1)+'⭐', cls:'gold', icon:'star' },
      ].map(s=>`<div class="kpi-card ${s.cls}">
        <div class="kpi-header"><div class="kpi-icon" style="background:var(--${s.cls}-light,var(--bg-hover));color:var(--${s.cls},var(--accent))"><i data-lucide="${s.icon}"></i></div></div>
        <div class="kpi-value">${s.val}</div><div class="kpi-label">${s.label}</div>
      </div>`).join('')}
    </div>

    <!-- Filters -->
    <div class="filter-bar">
      <div class="search-box">
        <i data-lucide="search"></i>
        <input type="text" placeholder="Nom, téléphone, permis..." id="driver-search" oninput="filterDrivers()" value="${driverFilter.search}" />
      </div>
      <select class="filter-select" id="driver-status-filter" onchange="filterDrivers()">
        <option value="">Tous les statuts</option>
        <option value="active" ${driverFilter.status==='active'?'selected':''}>Actifs</option>
        <option value="inactive" ${driverFilter.status==='inactive'?'selected':''}>Inactifs</option>
      </select>
    </div>

    <!-- Driver Cards Grid -->
    <div id="drivers-container" class="grid-3"></div>
  `;
  document.getElementById('page-content').innerHTML = html;
  lucide.createIcons();
  renderDriverList();
}

function renderDriverList() {
  const drivers = DB.drivers().filter(d => {
    const q = driverFilter.search.toLowerCase();
    const match = !q || (d.firstName+' '+d.lastName).toLowerCase().includes(q) || d.phone.includes(q) || d.licenseNo.toLowerCase().includes(q);
    const matchS = !driverFilter.status || d.status === driverFilter.status;
    return match && matchS;
  });

  const container = document.getElementById('drivers-container');
  if (!container) return;

  if (drivers.length === 0) {
    container.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
      <div class="empty-state-icon"><i data-lucide="users"></i></div>
      <h3>Aucun conducteur trouvé</h3>
      <p>Modifiez vos filtres ou ajoutez un conducteur</p>
      <button class="btn btn-primary" onclick="openDriverModal()"><i data-lucide="user-plus"></i> Ajouter</button>
    </div>`;
    lucide.createIcons();
    return;
  }

  container.innerHTML = drivers.map(d => {
    const vehicle = d.vehicleId ? Stats.vehicleById(d.vehicleId) : null;
    const licDays = daysFromNow(d.licenseExpiry);
    const contractClr = { CDI:'badge-success', CDD:'badge-warning', Intérimaire:'badge-info' };
    const rev30 = DB.payments().filter(p=>p.driverId===d.id && p.status==='paid' && new Date(p.date) >= (() => { const dt=new Date(); dt.setDate(dt.getDate()-30); return dt; })()).reduce((s,p)=>s+p.amount,0);
    const stars = '⭐'.repeat(Math.round(d.rating));

    return `<div class="driver-card">
      <div class="driver-card-header">
        <div class="avatar lg" style="background:linear-gradient(135deg,var(--secondary),var(--accent))">${initials(d.firstName+' '+d.lastName)}</div>
        <div class="driver-card-info">
          <div class="driver-name">${d.firstName} ${d.lastName}</div>
          <div class="driver-meta">${d.phone}</div>
          <div style="display:flex;gap:6px;margin-top:4px;flex-wrap:wrap">
            <span class="badge ${d.status==='active'?'badge-success':'badge-warning'}">${d.status==='active'?'Actif':'Inactif'}</span>
            <span class="badge ${contractClr[d.contract]||'badge-muted'}">${d.contract}</span>
          </div>
        </div>
      </div>

      <div class="driver-stats">
        <div class="driver-stat-box">
          <div class="val">${fmtNum(d.totalTrips)}</div>
          <div class="key">Trajets</div>
        </div>
        <div class="driver-stat-box">
          <div class="val">${fmtNum(Math.round(d.totalKm/1000))}k</div>
          <div class="key">km totaux</div>
        </div>
        <div class="driver-stat-box">
          <div class="val">${fmtNum(Math.round(rev30/1000))}k</div>
          <div class="key">Rev 30j</div>
        </div>
      </div>

      <div style="font-size:0.78rem;color:var(--text-secondary);display:flex;flex-direction:column;gap:6px">
        <div style="display:flex;justify-content:space-between">
          <span>Véhicule assigné:</span>
          <strong>${vehicle ? vehicle.plate : '—'}</strong>
        </div>
        <div style="display:flex;justify-content:space-between">
          <span>Permis expire:</span>
          <strong class="${licDays < 90 ? 'text-warning' : licDays < 30 ? 'text-danger' : ''}">${fmtDate(d.licenseExpiry)}</strong>
        </div>
        <div style="display:flex;justify-content:space-between">
          <span>Salaire mensuel:</span>
          <strong>${fmtCurrency(d.salary)}</strong>
        </div>
        <div style="display:flex;justify-content:space-between">
          <span>Note:</span>
          <strong>${d.rating} ${stars.slice(0,5)}</strong>
        </div>
      </div>

      <div class="divider"></div>
      <div class="driver-card-footer">
        <button class="btn btn-ghost btn-sm" onclick="openDriverDetail('${d.id}')"><i data-lucide="eye"></i> Détail</button>
        <button class="btn btn-outline btn-sm" onclick="openDriverModal('${d.id}')"><i data-lucide="pencil"></i> Modifier</button>
        <button class="btn btn-ghost btn-sm" onclick="confirmDeleteDriver('${d.id}')" style="color:var(--danger)"><i data-lucide="trash-2"></i></button>
      </div>
    </div>`;
  }).join('');
  lucide.createIcons();
}

function filterDrivers() {
  driverFilter.search = document.getElementById('driver-search')?.value || '';
  driverFilter.status = document.getElementById('driver-status-filter')?.value || '';
  renderDriverList();
}

function openDriverModal(id = null) {
  const d = id ? Stats.driverById(id) : null;
  const vehicles = DB.vehicles().filter(v => v.status === 'active');

  const body = `<form id="driver-form">
    <div class="form-row">
      <div class="form-group">
        <label class="form-label required">Prénom</label>
        <input class="form-control" id="df-first" value="${d?.firstName||''}" placeholder="Mamadou" required />
      </div>
      <div class="form-group">
        <label class="form-label required">Nom</label>
        <input class="form-control" id="df-last" value="${d?.lastName||''}" placeholder="Diallo" required />
      </div>
      <div class="form-group">
        <label class="form-label required">Téléphone</label>
        <input class="form-control" id="df-phone" value="${d?.phone||''}" placeholder="+221 77 000 00 00" required />
      </div>
      <div class="form-group">
        <label class="form-label">Email</label>
        <input class="form-control" id="df-email" type="email" value="${d?.email||''}" placeholder="email@exemple.com" />
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label required">N° Permis</label>
        <input class="form-control" id="df-license" value="${d?.licenseNo||''}" placeholder="SEN-2020-00000" required />
      </div>
      <div class="form-group">
        <label class="form-label required">Expir. Permis</label>
        <input class="form-control" id="df-license-exp" type="date" value="${d?.licenseExpiry||''}" required />
      </div>
      <div class="form-group">
        <label class="form-label">Type de contrat</label>
        <select class="form-control" id="df-contract">
          ${['CDI','CDD','Intérimaire','Freelance'].map(c=>`<option ${d?.contract===c?'selected':''}>${c}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Salaire mensuel (FCFA)</label>
        <input class="form-control" id="df-salary" type="number" value="${d?.salary||0}" />
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Date de début</label>
        <input class="form-control" id="df-start" type="date" value="${d?.startDate||''}" />
      </div>
      <div class="form-group">
        <label class="form-label">Véhicule assigné</label>
        <select class="form-control" id="df-vehicle">
          <option value="">— Non assigné —</option>
          ${vehicles.map(v=>`<option value="${v.id}" ${d?.vehicleId===v.id?'selected':''}>${v.plate} — ${v.brand} ${v.model}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Statut</label>
        <select class="form-control" id="df-status">
          <option value="active" ${d?.status==='active'?'selected':''}>Actif</option>
          <option value="inactive" ${d?.status==='inactive'?'selected':''}>Inactif</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Note (/5)</label>
        <input class="form-control" id="df-rating" type="number" min="0" max="5" step="0.1" value="${d?.rating||4.5}" />
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Notes</label>
      <textarea class="form-control" id="df-notes" rows="2">${d?.notes||''}</textarea>
    </div>
  </form>`;

  openModal(d ? `Modifier — ${d.firstName} ${d.lastName}` : 'Ajouter un conducteur', body, [
    { label: 'Annuler', cls: 'btn-outline', action: closeModal },
    { label: d ? 'Mettre à jour' : 'Ajouter', cls: 'btn-primary', action: () => saveDriver(id) }
  ]);
}

function saveDriver(id) {
  const firstName = document.getElementById('df-first')?.value.trim();
  const lastName  = document.getElementById('df-last')?.value.trim();
  const phone     = document.getElementById('df-phone')?.value.trim();
  if (!firstName || !lastName || !phone) { showToast('error', 'Erreur', 'Champs obligatoires manquants'); return; }

  const data = {
    firstName, lastName, phone,
    email: document.getElementById('df-email').value,
    licenseNo: document.getElementById('df-license').value,
    licenseExpiry: document.getElementById('df-license-exp').value,
    contract: document.getElementById('df-contract').value,
    salary: +document.getElementById('df-salary').value,
    startDate: document.getElementById('df-start').value,
    vehicleId: document.getElementById('df-vehicle').value || null,
    status: document.getElementById('df-status').value,
    rating: parseFloat(document.getElementById('df-rating').value),
    notes: document.getElementById('df-notes').value,
  };

  const drivers = DB.drivers();
  if (id) {
    const idx = drivers.findIndex(d => d.id === id);
    if (idx > -1) drivers[idx] = { ...drivers[idx], ...data };
    showToast('success', 'Mis à jour', `${firstName} ${lastName} modifié`);
  } else {
    drivers.push({ id: uid(), totalTrips: 0, totalKm: 0, ...data });
    showToast('success', 'Ajouté', `${firstName} ${lastName} enregistré`);
  }
  DB.saveDrivers(drivers);
  closeModal();
  renderDrivers();
  updateBadges();
}

function openDriverDetail(id) {
  const d = Stats.driverById(id);
  if (!d) return;
  const vehicle = d.vehicleId ? Stats.vehicleById(d.vehicleId) : null;
  const payments = DB.payments().filter(p => p.driverId === id).sort((a,b) => b.date.localeCompare(a.date)).slice(0, 8);
  const rev30 = payments.filter(p=>p.status==='paid').reduce((s,p)=>s+p.amount,0);

  const body = `
    <div style="display:flex;gap:20px;align-items:flex-start;margin-bottom:20px">
      <div class="avatar xl" style="background:linear-gradient(135deg,var(--secondary),var(--accent))">${initials(d.firstName+' '+d.lastName)}</div>
      <div style="flex:1">
        <h2 style="font-size:1.3rem;font-weight:800;margin-bottom:4px">${d.firstName} ${d.lastName}</h2>
        <div style="color:var(--text-secondary);font-size:0.875rem">${d.phone} · ${d.email}</div>
        <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap">
          <span class="badge ${d.status==='active'?'badge-success':'badge-warning'}">${d.status==='active'?'Actif':'Inactif'}</span>
          <span class="badge badge-secondary">${d.contract}</span>
          <span class="badge badge-muted">Note: ${d.rating}⭐</span>
        </div>
      </div>
    </div>
    <div style="display:flex;gap:12px;margin-bottom:20px">
      <div class="mini-kpi"><div class="mini-kpi-val text-accent">${fmtNum(d.totalTrips)}</div><div class="mini-kpi-label">Trajets</div></div>
      <div class="mini-kpi"><div class="mini-kpi-val">${fmtNum(Math.round(d.totalKm/1000))}k km</div><div class="mini-kpi-label">Distance</div></div>
      <div class="mini-kpi"><div class="mini-kpi-val text-success">${fmtNum(Math.round(rev30/1000))}k</div><div class="mini-kpi-label">Rev. 30j</div></div>
      <div class="mini-kpi"><div class="mini-kpi-val">${fmtCurrency(d.salary)}</div><div class="mini-kpi-label">Salaire</div></div>
    </div>
    <div class="detail-info-grid" style="margin-bottom:20px">
      <div class="detail-field"><label>N° Permis</label><span>${d.licenseNo}</span></div>
      <div class="detail-field"><label>Expir. Permis</label><span class="${daysFromNow(d.licenseExpiry)<90?'text-warning':''}">${fmtDate(d.licenseExpiry)}</span></div>
      <div class="detail-field"><label>Véhicule</label><span>${vehicle ? vehicle.plate+' — '+vehicle.brand+' '+vehicle.model : '—'}</span></div>
      <div class="detail-field"><label>Début contrat</label><span>${fmtDate(d.startDate)}</span></div>
    </div>
    <h4 style="font-size:0.875rem;font-weight:700;margin-bottom:12px;color:var(--text-secondary)">Historique versements récents</h4>
    <div class="table-wrapper">
      <table class="table">
        <thead><tr><th>Date</th><th>Montant</th><th>Méthode</th><th>Statut</th></tr></thead>
        <tbody>
          ${payments.map(p => {
            const sMap = { paid:['badge-success','Payé'], pending:['badge-warning','En attente'], late:['badge-danger','En retard'] };
            const [cls,lbl] = sMap[p.status]||['badge-muted',p.status];
            return `<tr><td>${fmtDateShort(p.date)}</td><td class="font-mono">${fmtCurrency(p.amount)}</td><td>${p.method}</td><td><span class="badge ${cls}">${lbl}</span></td></tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;

  openModal('Profil Conducteur', body, [
    { label: 'Fermer', cls: 'btn-outline', action: closeModal },
    { label: 'Modifier', cls: 'btn-primary', action: () => { closeModal(); openDriverModal(id); } }
  ], 'modal-lg');
}

function confirmDeleteDriver(id) {
  const d = Stats.driverById(id);
  if (!d) return;
  openModal('Confirmer la suppression',
    `<div class="info-box info-danger"><i data-lucide="alert-triangle"></i><span>Supprimer le conducteur <strong>${d.firstName} ${d.lastName}</strong> ? Cette action est irréversible.</span></div>`,
    [
      { label: 'Annuler', cls: 'btn-outline', action: closeModal },
      { label: 'Supprimer', cls: 'btn-danger', action: () => {
        DB.saveDrivers(DB.drivers().filter(x => x.id !== id));
        showToast('success', 'Supprimé', `${d.firstName} ${d.lastName} supprimé`);
        closeModal(); renderDrivers(); updateBadges();
      }}
    ]
  );
}

function exportDriversCSV() {
  const rows = [['Prénom','Nom','Téléphone','Email','N° Permis','Expir. Permis','Contrat','Salaire','Statut','Véhicule','Trajets','Km total']];
  DB.drivers().forEach(d => {
    const v = d.vehicleId ? Stats.vehicleById(d.vehicleId) : null;
    rows.push([d.firstName, d.lastName, d.phone, d.email, d.licenseNo, d.licenseExpiry, d.contract, d.salary, d.status, v?v.plate:'', d.totalTrips, d.totalKm]);
  });
  downloadCSV(rows, 'conducteurs_flotte2.csv');
}
