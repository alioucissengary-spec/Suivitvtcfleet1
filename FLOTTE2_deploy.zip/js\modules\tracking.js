/* ============================================================
   FLOTTE 2.0 — GPS Tracking Module
   ============================================================ */

let fleetMap = null;
let mapMarkers = {};
let trackingInterval = null;
let selectedVehicleTracking = null;

const MOCK_POSITIONS = {
  'v001': { lat: 14.7167, lng: -17.4677, speed: 42, heading: 90,  address: 'Dakar - Plateau' },
  'v002': { lat: 14.7645, lng: -17.3660, speed: 68, heading: 45,  address: 'Autoroute Dakar-Thiès' },
  'v004': { lat: 14.7800, lng: -17.4500, speed: 25, heading: 180, address: 'Guédiawaye, Dakar' },
  'v006': { lat: 14.4165, lng: -16.9668, speed: 85, heading: 135, address: 'Route Nationale 1, Mbour' },
};

function renderTracking() {
  const activeVehicles = DB.vehicles().filter(v => v.status === 'active');
  const trips = DB.trips().filter(t => t.status === 'active');

  const html = `
    <div class="page-header">
      <div class="page-header-left">
        <h1>Suivi GPS de la Flotte</h1>
        <p class="page-subtitle">
          <span class="live-dot" style="display:inline-block;margin-right:8px"></span>
          ${activeVehicles.length} véhicules actifs · ${trips.length} trajets en cours
        </p>
      </div>
      <div class="page-actions">
        <button class="btn btn-outline btn-sm" onclick="refreshMap()"><i data-lucide="refresh-cw"></i> Actualiser</button>
        <button class="btn btn-primary btn-sm" onclick="openTripModal()"><i data-lucide="map-pin"></i> Nouveau trajet</button>
      </div>
    </div>

    <div class="grid-12">
      <!-- Map -->
      <div class="col-8">
        <div class="map-container" style="position:relative">
          <div id="fleet-map"></div>
          <div class="map-legend">
            <div class="map-legend-item"><div class="legend-dot" style="background:var(--success)"></div>En service</div>
            <div class="map-legend-item"><div class="legend-dot" style="background:var(--warning)"></div>Arrêté</div>
            <div class="map-legend-item"><div class="legend-dot" style="background:var(--danger)"></div>Urgence</div>
          </div>
        </div>
      </div>

      <!-- Vehicle List -->
      <div class="col-4">
        <div class="card" style="height:450px;display:flex;flex-direction:column">
          <div class="card-header">
            <span class="card-title"><i data-lucide="list"></i> Véhicules actifs</span>
            <span class="nav-live">LIVE</span>
          </div>
          <div class="tracking-vehicles" id="tracking-vehicle-list" style="flex:1;padding:8px">
            ${activeVehicles.map(v => {
              const pos = MOCK_POSITIONS[v.id];
              const driver = v.driverId ? Stats.driverById(v.driverId) : null;
              const isMoving = pos && pos.speed > 0;
              return `<div class="tracking-vehicle-item ${selectedVehicleTracking===v.id?'active':''}" id="track-item-${v.id}" onclick="selectVehicle('${v.id}')">
                <div style="font-size:1.4rem">🚐</div>
                <div class="tracking-vehicle-info">
                  <div class="tracking-vehicle-plate">${v.plate}</div>
                  <div class="tracking-vehicle-status">${driver?driver.firstName+' '+driver.lastName:'—'}</div>
                  <div style="font-size:0.7rem;color:var(--text-muted)">${pos?pos.address:'Position inconnue'}</div>
                </div>
                <div style="text-align:right">
                  <div class="tracking-speed" id="speed-${v.id}">${pos?pos.speed:0} km/h</div>
                  <div style="width:8px;height:8px;border-radius:50%;background:${isMoving?'var(--success)':'var(--warning)'};margin-left:auto;margin-top:4px"></div>
                </div>
              </div>`;
            }).join('')}
          </div>
        </div>
      </div>
    </div>

    <!-- Active Trips -->
    <div class="card mt-4">
      <div class="card-header">
        <span class="card-title"><i data-lucide="route"></i> Trajets en cours & historique</span>
      </div>
      <div class="table-wrapper" style="border:none;border-radius:0">
        <table class="table">
          <thead><tr><th>Véhicule</th><th>Conducteur</th><th>Départ</th><th>Arrivée</th><th>Distance</th><th>Passagers</th><th>Statut</th></tr></thead>
          <tbody>
            ${DB.trips().sort((a,b)=>b.date.localeCompare(a.date)).map(t => {
              const v = Stats.vehicleById(t.vehicleId);
              const d = Stats.driverById(t.driverId);
              const sMap = { active:['badge-accent','En cours'], completed:['badge-success','Terminé'], cancelled:['badge-danger','Annulé'] };
              const [cls,lbl] = sMap[t.status]||['badge-muted',t.status];
              return `<tr>
                <td><code class="font-mono text-sm">${v?v.plate:'—'}</code></td>
                <td>${d?d.firstName+' '+d.lastName:'—'}</td>
                <td>${t.departure}</td>
                <td>${t.arrival}</td>
                <td class="font-mono">${t.distance} km</td>
                <td>${t.passengers}</td>
                <td><span class="badge ${cls}"><span class="status-dot"></span>${lbl}</span></td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  document.getElementById('page-content').innerHTML = html;
  lucide.createIcons();

  setTimeout(() => {
    initMap();
    startLiveTracking();
  }, 100);
}

function initMap() {
  if (fleetMap) { fleetMap.remove(); fleetMap = null; }
  const mapEl = document.getElementById('fleet-map');
  if (!mapEl) return;

  fleetMap = L.map('fleet-map', { zoomControl: true }).setView([14.7167, -17.4677], 10);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors',
    maxZoom: 18,
  }).addTo(fleetMap);

  DB.vehicles().filter(v => v.status === 'active').forEach(v => {
    const pos = MOCK_POSITIONS[v.id];
    if (!pos) return;
    const driver = v.driverId ? Stats.driverById(v.driverId) : null;
    const isMoving = pos.speed > 0;

    const iconHtml = `<div style="
      background:${isMoving ? '#00C9A7' : '#D29922'};
      border:3px solid white;
      border-radius:50%;
      width:36px;height:36px;
      display:flex;align-items:center;justify-content:center;
      font-size:16px;box-shadow:0 2px 8px rgba(0,0,0,0.4);
      cursor:pointer;
    ">🚐</div>`;

    const icon = L.divIcon({ html: iconHtml, className: '', iconSize: [36, 36], iconAnchor: [18, 18] });
    const marker = L.marker([pos.lat, pos.lng], { icon })
      .addTo(fleetMap)
      .bindPopup(`
        <div style="font-family:Inter,sans-serif;min-width:180px">
          <strong style="font-size:0.9rem">${v.plate}</strong><br>
          <span style="color:#8B949E;font-size:0.8rem">${v.brand} ${v.model}</span><br>
          <hr style="margin:6px 0;border-color:#30363D">
          ${driver ? `<div style="font-size:0.8rem">👤 ${driver.firstName} ${driver.lastName}</div>` : ''}
          <div style="font-size:0.8rem">📍 ${pos.address}</div>
          <div style="font-size:0.8rem">⚡ ${pos.speed} km/h</div>
        </div>
      `);
    mapMarkers[v.id] = marker;
  });
}

function selectVehicle(vehicleId) {
  selectedVehicleTracking = vehicleId;
  document.querySelectorAll('.tracking-vehicle-item').forEach(el => el.classList.remove('active'));
  const item = document.getElementById('track-item-' + vehicleId);
  if (item) item.classList.add('active');

  const pos = MOCK_POSITIONS[vehicleId];
  if (pos && fleetMap) {
    fleetMap.flyTo([pos.lat, pos.lng], 14, { duration: 1 });
    const marker = mapMarkers[vehicleId];
    if (marker) marker.openPopup();
  }
}

function refreshMap() {
  Object.keys(MOCK_POSITIONS).forEach(vid => {
    const pos = MOCK_POSITIONS[vid];
    pos.lat += (Math.random() - 0.5) * 0.005;
    pos.lng += (Math.random() - 0.5) * 0.005;
    pos.speed = Math.max(0, pos.speed + randomBetween(-10, 10));
    const speedEl = document.getElementById('speed-' + vid);
    if (speedEl) speedEl.textContent = pos.speed + ' km/h';
    const marker = mapMarkers[vid];
    if (marker) marker.setLatLng([pos.lat, pos.lng]);
  });
  showToast('info', 'GPS', 'Positions actualisées');
}

function startLiveTracking() {
  if (trackingInterval) clearInterval(trackingInterval);
  trackingInterval = setInterval(() => {
    Object.keys(MOCK_POSITIONS).forEach(vid => {
      const pos = MOCK_POSITIONS[vid];
      pos.lat += (Math.random() - 0.5) * 0.002;
      pos.lng += (Math.random() - 0.5) * 0.002;
      pos.speed = Math.max(0, Math.min(120, pos.speed + randomBetween(-5, 5)));
      const speedEl = document.getElementById('speed-' + vid);
      if (speedEl) speedEl.textContent = pos.speed + ' km/h';
      const marker = mapMarkers[vid];
      if (marker && fleetMap) marker.setLatLng([pos.lat, pos.lng]);
    });
  }, 5000);
}

function openTripModal() {
  const body = `<form id="trip-form">
    <div class="form-row">
      <div class="form-group">
        <label class="form-label required">Véhicule</label>
        <select class="form-control" id="tf-vehicle" required>
          <option value="">— Sélectionner —</option>
          ${DB.vehicles().filter(v=>v.status==='active').map(v=>`<option value="${v.id}">${v.plate} — ${v.brand} ${v.model}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label required">Conducteur</label>
        <select class="form-control" id="tf-driver" required>
          <option value="">— Sélectionner —</option>
          ${DB.drivers().filter(d=>d.status==='active').map(d=>`<option value="${d.id}">${d.firstName} ${d.lastName}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label required">Point de départ</label>
        <input class="form-control" id="tf-dep" placeholder="Ex: Dakar - Plateau" required />
      </div>
      <div class="form-group">
        <label class="form-label required">Destination</label>
        <input class="form-control" id="tf-arr" placeholder="Ex: Thiès" required />
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Distance estimée (km)</label>
        <input class="form-control" id="tf-dist" type="number" min="1" value="50" />
      </div>
      <div class="form-group">
        <label class="form-label">Nombre de passagers</label>
        <input class="form-control" id="tf-pass" type="number" min="0" value="0" />
      </div>
    </div>
  </form>`;

  openModal('Nouveau Trajet', body, [
    { label: 'Annuler', cls: 'btn-outline', action: closeModal },
    { label: 'Démarrer', cls: 'btn-primary', action: () => {
      const vId = document.getElementById('tf-vehicle')?.value;
      const dId = document.getElementById('tf-driver')?.value;
      const dep = document.getElementById('tf-dep')?.value;
      const arr = document.getElementById('tf-arr')?.value;
      if (!vId || !dId || !dep || !arr) { showToast('error','Erreur','Champs obligatoires'); return; }
      const trips = DB.trips();
      trips.push({ id:uid(), vehicleId:vId, driverId:dId, departure:dep, arrival:arr,
        distance:+document.getElementById('tf-dist').value,
        passengers:+document.getElementById('tf-pass').value,
        date:today(), status:'active' });
      DB.saveTrips(trips);
      showToast('success','Trajet démarré','Le trajet est en cours');
      closeModal();
      renderTracking();
    }}
  ]);
}
