/* ============================================================
   FLOTTE 2.0 — Vehicles Module
   ============================================================ */

let vehicleView = 'grid'; /* grid | list */
let vehicleFilter = { search: '', status: '', type: '' };

function renderVehicles() {
  const html = `
    <div class="page-header">
      <div class="page-header-left">
        <h1>Gestion des Véhicules</h1>
        <p class="page-subtitle">${DB.vehicles().length} véhicules enregistrés dans la flotte</p>
      </div>
      <div class="page-actions">
        <button class="btn btn-outline btn-sm" onclick="exportVehiclesCSV()"><i data-lucide="download"></i> Exporter</button>
        <button class="btn btn-primary" id="add-vehicle-btn" onclick="openVehicleModal()">
          <i data-lucide="plus"></i> Ajouter un véhicule
        </button>
      </div>
    </div>

    <!-- Stats Bar -->
    <div class="kpi-grid" style="margin-bottom:var(--space-5)">
      ${[
        { label: 'Total', val: DB.vehicles().length, cls: 'secondary', icon: 'car' },
        { label: 'Actifs', val: DB.vehicles().filter(v=>v.status==='active').length, cls: 'success', icon: 'circle-check' },
        { label: 'Maintenance', val: DB.vehicles().filter(v=>v.status==='maintenance').length, cls: 'warning', icon: 'wrench' },
        { label: 'Inactifs', val: DB.vehicles().filter(v=>v.status==='inactive').length, cls: 'danger', icon: 'circle-x' },
      ].map(s => `
        <div class="kpi-card ${s.cls}">
          <div class="kpi-header">
            <div class="kpi-icon" style="background:var(--${s.cls}-light);color:var(--${s.cls})"><i data-lucide="${s.icon}"></i></div>
          </div>
          <div class="kpi-value">${s.val}</div>
          <div class="kpi-label">${s.label}</div>
        </div>
      `).join('')}
    </div>

    <!-- Filters -->
    <div class="filter-bar">
      <div class="search-box">
        <i data-lucide="search"></i>
        <input type="text" placeholder="Plaque, marque, modèle..." id="vehicle-search" oninput="filterVehicles()" value="${vehicleFilter.search}" />
      </div>
      <select class="filter-select" id="vehicle-status-filter" onchange="filterVehicles()">
        <option value="">Tous les statuts</option>
        <option value="active" ${vehicleFilter.status==='active'?'selected':''}>Actifs</option>
        <option value="maintenance" ${vehicleFilter.status==='maintenance'?'selected':''}>En maintenance</option>
        <option value="inactive" ${vehicleFilter.status==='inactive'?'selected':''}>Inactifs</option>
      </select>
      <select class="filter-select" id="vehicle-type-filter" onchange="filterVehicles()">
        <option value="">Tous les types</option>
        <option value="bus" ${vehicleFilter.type==='bus'?'selected':''}>Bus</option>
        <option value="minibus" ${vehicleFilter.type==='minibus'?'selected':''}>Minibus</option>
        <option value="van" ${vehicleFilter.type==='van'?'selected':''}>Van</option>
      </select>
      <div style="margin-left:auto;display:flex;gap:4px">
        <button class="btn btn-icon btn-outline btn-sm ${vehicleView==='grid'?'btn-primary':''}" onclick="setVehicleView('grid')" title="Vue grille"><i data-lucide="grid-2x2"></i></button>
        <button class="btn btn-icon btn-outline btn-sm ${vehicleView==='list'?'btn-primary':''}" onclick="setVehicleView('list')" title="Vue liste"><i data-lucide="list"></i></button>
      </div>
    </div>

    <!-- Vehicle List -->
    <div id="vehicles-container"></div>
  `;

  document.getElementById('page-content').innerHTML = html;
  lucide.createIcons();
  renderVehicleList();
}

function getFilteredVehicles() {
  return DB.vehicles().filter(v => {
    const q = vehicleFilter.search.toLowerCase();
    const matchSearch = !q || v.plate.toLowerCase().includes(q) || v.brand.toLowerCase().includes(q) || v.model.toLowerCase().includes(q);
    const matchStatus = !vehicleFilter.status || v.status === vehicleFilter.status;
    const matchType   = !vehicleFilter.type   || v.type   === vehicleFilter.type;
    return matchSearch && matchStatus && matchType;
  });
}

function renderVehicleList() {
  const vehicles = getFilteredVehicles();
  const container = document.getElementById('vehicles-container');
  if (!container) return;

  if (vehicles.length === 0) {
    container.innerHTML = `<div class="empty-state">
      <div class="empty-state-icon"><i data-lucide="car"></i></div>
      <h3>Aucun véhicule trouvé</h3>
      <p>Modifiez vos filtres ou ajoutez un véhicule</p>
      <button class="btn btn-primary" onclick="openVehicleModal()"><i data-lucide="plus"></i> Ajouter</button>
    </div>`;
    lucide.createIcons();
    return;
  }

  const typeEmoji = { bus: '🚌', minibus: '🚐', van: '🚙', truck: '🚛', other: '🚗' };
  const statusMap = { active: ['badge-success','Actif'], maintenance: ['badge-warning','Maintenance'], inactive: ['badge-danger','Inactif'] };

  if (vehicleView === 'grid') {
    container.innerHTML = `<div class="vehicles-grid">
      ${vehicles.map(v => {
        const driver = v.driverId ? Stats.driverById(v.driverId) : null;
        const [sCls, sLabel] = statusMap[v.status] || ['badge-muted', v.status];
        const daysToMaint = daysFromNow(v.nextMaintenance);
        const vRev = Stats.vehicleRevenue(v.id, 30);
        return `<div class="vehicle-card" onclick="openVehicleDetail('${v.id}')">
          <div class="vehicle-card-img">
            <div class="vehicle-type-icon">${typeEmoji[v.type] || '🚗'}</div>
            <div class="vehicle-card-status"><span class="badge ${sCls}"><span class="status-dot"></span>${sLabel}</span></div>
          </div>
          <div class="vehicle-card-body">
            <div class="vehicle-card-plate">${v.plate}</div>
            <div class="vehicle-card-model">${v.brand} ${v.model} · ${v.year}</div>
            <div class="vehicle-card-stats">
              <div class="vehicle-stat">
                <span class="vehicle-stat-val">${fmtNum(v.km)}</span>
                <span class="vehicle-stat-key">km</span>
              </div>
              <div class="vehicle-stat">
                <span class="vehicle-stat-val">${v.seats}</span>
                <span class="vehicle-stat-key">Places</span>
              </div>
              <div class="vehicle-stat">
                <span class="vehicle-stat-val ${daysToMaint < 7 ? 'text-danger' : daysToMaint < 30 ? 'text-warning' : 'text-success'}">${daysToMaint < 0 ? 'Dépassé' : daysToMaint + 'j'}</span>
                <span class="vehicle-stat-key">Maintenance</span>
              </div>
              <div class="vehicle-stat">
                <span class="vehicle-stat-val">${fmtNum(Math.round(vRev/1000))}k</span>
                <span class="vehicle-stat-key">Rev/30j</span>
              </div>
            </div>
          </div>
          <div class="vehicle-card-footer">
            <div class="vehicle-assigned">
              ${driver ? `<div class="avatar" style="width:22px;height:22px;font-size:0.6rem">${initials(driver.firstName+' '+driver.lastName)}</div><span>${driver.firstName} ${driver.lastName}</span>` : '<span style="color:var(--text-muted)">Non assigné</span>'}
            </div>
            <div style="display:flex;gap:4px">
              <button class="btn btn-icon btn-ghost btn-sm" onclick="event.stopPropagation();openVehicleModal('${v.id}')" title="Modifier"><i data-lucide="pencil"></i></button>
              <button class="btn btn-icon btn-ghost btn-sm" onclick="event.stopPropagation();confirmDeleteVehicle('${v.id}')" title="Supprimer"><i data-lucide="trash-2"></i></button>
            </div>
          </div>
        </div>`;
      }).join('')}
    </div>`;
  } else {
    container.innerHTML = `<div class="table-wrapper">
      <table class="table">
        <thead>
          <tr>
            <th>Plaque</th><th>Véhicule</th><th>Type</th><th>Statut</th>
            <th>Kilométrage</th><th>Conducteur</th><th>Rev. 30j</th><th>Maint.</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${vehicles.map(v => {
            const driver = v.driverId ? Stats.driverById(v.driverId) : null;
            const [sCls, sLabel] = statusMap[v.status] || ['badge-muted', v.status];
            const daysToMaint = daysFromNow(v.nextMaintenance);
            const vRev = Stats.vehicleRevenue(v.id, 30);
            return `<tr style="cursor:pointer" onclick="openVehicleDetail('${v.id}')">
              <td><code style="font-family:var(--font-mono);font-weight:700">${v.plate}</code></td>
              <td>
                <div class="font-bold">${v.brand} ${v.model}</div>
                <div class="text-xs text-muted">${v.year} · ${v.color}</div>
              </td>
              <td>${typeEmoji[v.type]} ${v.type}</td>
              <td><span class="badge ${sCls}"><span class="status-dot"></span>${sLabel}</span></td>
              <td class="font-mono">${fmtNum(v.km)} km</td>
              <td>${driver ? `<div style="display:flex;align-items:center;gap:6px"><div class="avatar" style="width:24px;height:24px;font-size:0.65rem">${initials(driver.firstName+' '+driver.lastName)}</div>${driver.firstName} ${driver.lastName}</div>` : '<span class="text-muted">—</span>'}</td>
              <td class="font-mono text-accent">${fmtNum(Math.round(vRev/1000))}k</td>
              <td class="${daysToMaint < 7 ? 'text-danger' : daysToMaint < 30 ? 'text-warning' : 'text-success'}">${daysToMaint < 0 ? 'Dépassé' : daysToMaint + 'j'}</td>
              <td onclick="event.stopPropagation()">
                <div class="table-actions">
                  <button class="btn btn-icon btn-ghost btn-sm" onclick="openVehicleDetail('${v.id}')" title="Détail"><i data-lucide="eye"></i></button>
                  <button class="btn btn-icon btn-ghost btn-sm" onclick="openVehicleModal('${v.id}')" title="Modifier"><i data-lucide="pencil"></i></button>
                  <button class="btn btn-icon btn-ghost btn-sm" onclick="confirmDeleteVehicle('${v.id}')" title="Supprimer"><i data-lucide="trash-2"></i></button>
                </div>
              </td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`;
  }
  lucide.createIcons();
}

function filterVehicles() {
  vehicleFilter.search = document.getElementById('vehicle-search')?.value || '';
  vehicleFilter.status = document.getElementById('vehicle-status-filter')?.value || '';
  vehicleFilter.type   = document.getElementById('vehicle-type-filter')?.value || '';
  renderVehicleList();
}

function setVehicleView(view) {
  vehicleView = view;
  renderVehicles();
}

function openVehicleModal(id = null) {
  const v = id ? Stats.vehicleById(id) : null;
  const title = v ? `Modifier — ${v.plate}` : 'Ajouter un véhicule';
  const drivers = DB.drivers().filter(d => d.status === 'active');

  const body = `
    <form id="vehicle-form">
      <div class="form-row">
        <div class="form-group">
          <label class="form-label required">Plaque d'immatriculation</label>
          <input class="form-control" id="f-plate" placeholder="DK-0000-AB" value="${v?.plate||''}" required />
        </div>
        <div class="form-group">
          <label class="form-label required">Marque</label>
          <input class="form-control" id="f-brand" placeholder="Toyota" value="${v?.brand||''}" required />
        </div>
        <div class="form-group">
          <label class="form-label required">Modèle</label>
          <input class="form-control" id="f-model" placeholder="Hiace" value="${v?.model||''}" required />
        </div>
        <div class="form-group">
          <label class="form-label">Année</label>
          <input class="form-control" id="f-year" type="number" min="2000" max="2030" value="${v?.year||new Date().getFullYear()}" />
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Type</label>
          <select class="form-control" id="f-type">
            ${['bus','minibus','van','truck','other'].map(t => `<option value="${t}" ${v?.type===t?'selected':''}>${t.charAt(0).toUpperCase()+t.slice(1)}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Couleur</label>
          <input class="form-control" id="f-color" placeholder="Blanc" value="${v?.color||''}" />
        </div>
        <div class="form-group">
          <label class="form-label">Carburant</label>
          <select class="form-control" id="f-fuel">
            ${['Diesel','Essence','Hybride','Électrique'].map(f => `<option ${v?.fuel===f?'selected':''}>${f}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Nombre de places</label>
          <input class="form-control" id="f-seats" type="number" min="1" value="${v?.seats||9}" />
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Kilométrage actuel</label>
          <input class="form-control" id="f-km" type="number" min="0" value="${v?.km||0}" />
        </div>
        <div class="form-group">
          <label class="form-label">Statut</label>
          <select class="form-control" id="f-status">
            <option value="active" ${v?.status==='active'?'selected':''}>Actif</option>
            <option value="maintenance" ${v?.status==='maintenance'?'selected':''}>En maintenance</option>
            <option value="inactive" ${v?.status==='inactive'?'selected':''}>Inactif</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Conducteur assigné</label>
          <select class="form-control" id="f-driver">
            <option value="">— Non assigné —</option>
            ${drivers.map(d => `<option value="${d.id}" ${v?.driverId===d.id?'selected':''}>${d.firstName} ${d.lastName}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Versement journalier cible (FCFA)</label>
          <input class="form-control" id="f-daily" type="number" min="0" value="${v?.dailyTarget||30000}" />
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Date d'achat</label>
          <input class="form-control" id="f-purchase-date" type="date" value="${v?.purchaseDate||''}" />
        </div>
        <div class="form-group">
          <label class="form-label">Prix d'achat (FCFA)</label>
          <input class="form-control" id="f-purchase-price" type="number" min="0" value="${v?.purchasePrice||0}" />
        </div>
        <div class="form-group">
          <label class="form-label">Expiration assurance</label>
          <input class="form-control" id="f-insurance" type="date" value="${v?.insuranceExpiry||''}" />
        </div>
        <div class="form-group">
          <label class="form-label">Prochaine maintenance</label>
          <input class="form-control" id="f-maintenance" type="date" value="${v?.nextMaintenance||''}" />
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Notes</label>
        <textarea class="form-control" id="f-notes" rows="2" placeholder="Informations supplémentaires...">${v?.notes||''}</textarea>
      </div>
    </form>
  `;

  openModal(title, body, [
    { label: 'Annuler', cls: 'btn-outline', action: closeModal },
    { label: v ? 'Mettre à jour' : 'Ajouter', cls: 'btn-primary', action: () => saveVehicle(id) }
  ]);
}

function saveVehicle(id) {
  const plate = document.getElementById('f-plate')?.value.trim();
  const brand = document.getElementById('f-brand')?.value.trim();
  const model = document.getElementById('f-model')?.value.trim();
  if (!plate || !brand || !model) { showToast('error', 'Erreur', 'Champs obligatoires manquants'); return; }

  const data = {
    plate, brand, model,
    year: +document.getElementById('f-year').value,
    type: document.getElementById('f-type').value,
    color: document.getElementById('f-color').value,
    fuel: document.getElementById('f-fuel').value,
    seats: +document.getElementById('f-seats').value,
    km: +document.getElementById('f-km').value,
    status: document.getElementById('f-status').value,
    driverId: document.getElementById('f-driver').value || null,
    dailyTarget: +document.getElementById('f-daily').value,
    purchaseDate: document.getElementById('f-purchase-date').value,
    purchasePrice: +document.getElementById('f-purchase-price').value,
    insuranceExpiry: document.getElementById('f-insurance').value,
    nextMaintenance: document.getElementById('f-maintenance').value,
    notes: document.getElementById('f-notes').value,
  };

  const vehicles = DB.vehicles();
  if (id) {
    const idx = vehicles.findIndex(v => v.id === id);
    if (idx > -1) vehicles[idx] = { ...vehicles[idx], ...data };
    showToast('success', 'Mis à jour', `Véhicule ${plate} modifié`);
  } else {
    vehicles.push({ id: uid(), ...data });
    showToast('success', 'Ajouté', `Véhicule ${plate} enregistré`);
  }
  DB.saveVehicles(vehicles);
  closeModal();
  renderVehicles();
  updateBadges();
}

function openVehicleDetail(id) {
  const v = Stats.vehicleById(id);
  if (!v) return;
  const driver = v.driverId ? Stats.driverById(v.driverId) : null;
  const typeEmoji = { bus: '🚌', minibus: '🚐', van: '🚙', truck: '🚛', other: '🚗' };
  const statusMap = { active: 'badge-success', maintenance: 'badge-warning', inactive: 'badge-danger' };
  const vRev = Stats.vehicleRevenue(v.id, 30);
  const vExp = Stats.vehicleExpenses(v.id, 30);
  const recentExp = DB.expenses().filter(e => e.vehicleId === id).sort((a,b) => b.date.localeCompare(a.date)).slice(0, 5);

  const body = `
    <div class="detail-panel" style="margin-bottom:var(--space-5)">
      <div class="detail-panel-img">${typeEmoji[v.type] || '🚗'}</div>
      <div>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
          <h2 style="font-size:1.4rem;font-weight:800;font-family:var(--font-mono)">${v.plate}</h2>
          <span class="badge ${statusMap[v.status]}">${v.status==='active'?'Actif':v.status==='maintenance'?'Maintenance':'Inactif'}</span>
        </div>
        <div class="detail-info-grid">
          <div class="detail-field"><label>Marque & Modèle</label><span>${v.brand} ${v.model}</span></div>
          <div class="detail-field"><label>Année</label><span>${v.year}</span></div>
          <div class="detail-field"><label>Type</label><span>${v.type}</span></div>
          <div class="detail-field"><label>Couleur</label><span>${v.color}</span></div>
          <div class="detail-field"><label>Carburant</label><span>${v.fuel}</span></div>
          <div class="detail-field"><label>Places</label><span>${v.seats}</span></div>
          <div class="detail-field"><label>Kilométrage</label><span>${fmtNum(v.km)} km</span></div>
          <div class="detail-field"><label>Conducteur</label><span>${driver ? driver.firstName+' '+driver.lastName : '—'}</span></div>
          <div class="detail-field"><label>Assurance expire</label><span class="${daysFromNow(v.insuranceExpiry)<30?'text-danger':''}">${fmtDate(v.insuranceExpiry)}</span></div>
          <div class="detail-field"><label>Prochaine maint.</label><span class="${daysFromNow(v.nextMaintenance)<7?'text-danger':daysFromNow(v.nextMaintenance)<30?'text-warning':''}">${fmtDate(v.nextMaintenance)}</span></div>
          <div class="detail-field"><label>Achat</label><span>${fmtDate(v.purchaseDate)}</span></div>
          <div class="detail-field"><label>Prix achat</label><span>${fmtCurrency(v.purchasePrice)}</span></div>
        </div>
      </div>
    </div>
    <div class="divider"></div>
    <div style="display:flex;gap:16px;margin-bottom:20px">
      <div class="mini-kpi"><div class="mini-kpi-val text-accent">${fmtNum(Math.round(vRev/1000))}k</div><div class="mini-kpi-label">Rev. 30j</div></div>
      <div class="mini-kpi"><div class="mini-kpi-val text-danger">${fmtNum(Math.round(vExp/1000))}k</div><div class="mini-kpi-label">Dép. 30j</div></div>
      <div class="mini-kpi"><div class="mini-kpi-val ${vRev-vExp>=0?'text-success':'text-danger'}">${fmtNum(Math.round((vRev-vExp)/1000))}k</div><div class="mini-kpi-label">Net 30j</div></div>
      <div class="mini-kpi"><div class="mini-kpi-val">${fmtCurrency(v.dailyTarget)}</div><div class="mini-kpi-label">Cible/jour</div></div>
    </div>
    ${v.notes ? `<div class="info-box info-accent" style="margin-bottom:16px"><i data-lucide="info"></i><span>${v.notes}</span></div>` : ''}
    <h4 style="font-size:0.875rem;font-weight:700;margin-bottom:12px;color:var(--text-secondary)">Dernières dépenses</h4>
    ${recentExp.length === 0 ? '<p class="text-muted text-sm">Aucune dépense enregistrée</p>' :
      `<div style="display:flex;flex-direction:column;gap:8px">
        ${recentExp.map(e => {
          const catLabel = { fuel:'Carburant', maintenance:'Maintenance', insurance:'Assurance', fine:'Amende', other:'Autre' };
          return `<div style="display:flex;align-items:center;gap:12px;padding:8px 12px;background:var(--bg-tertiary);border-radius:var(--radius)">
            <span style="flex:1;font-size:0.82rem">${e.description}</span>
            <span class="badge badge-muted">${catLabel[e.category]||e.category}</span>
            <strong class="font-mono text-sm">${fmtCurrency(e.amount)}</strong>
            <span class="text-xs text-muted">${fmtDateShort(e.date)}</span>
          </div>`;
        }).join('')}
      </div>`
    }
  `;

  openModal(`Détail Véhicule`, body, [
    { label: 'Fermer', cls: 'btn-outline', action: closeModal },
    { label: 'Modifier', cls: 'btn-primary', action: () => { closeModal(); openVehicleModal(id); } }
  ], 'modal-lg');
}

function confirmDeleteVehicle(id) {
  const v = Stats.vehicleById(id);
  if (!v) return;
  openModal('Confirmer la suppression',
    `<div class="info-box info-danger"><i data-lucide="alert-triangle"></i><span>Supprimer le véhicule <strong>${v.plate}</strong> ? Cette action est irréversible.</span></div>`,
    [
      { label: 'Annuler', cls: 'btn-outline', action: closeModal },
      { label: 'Supprimer', cls: 'btn-danger', action: () => {
        const vehicles = DB.vehicles().filter(x => x.id !== id);
        DB.saveVehicles(vehicles);
        showToast('success', 'Supprimé', `Véhicule ${v.plate} supprimé`);
        closeModal();
        renderVehicles();
        updateBadges();
      }}
    ]
  );
}

function exportVehiclesCSV() {
  const rows = [['Plaque','Marque','Modèle','Année','Type','Statut','Km','Places','Conducteur','Assurance','Prochaine Maint.']];
  DB.vehicles().forEach(v => {
    const driver = v.driverId ? Stats.driverById(v.driverId) : null;
    rows.push([v.plate, v.brand, v.model, v.year, v.type, v.status, v.km, v.seats, driver ? driver.firstName+' '+driver.lastName : '', v.insuranceExpiry, v.nextMaintenance]);
  });
  downloadCSV(rows, 'vehicules_flotte2.csv');
}
