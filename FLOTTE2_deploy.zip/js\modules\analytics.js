/* ============================================================
   FLOTTE 2.0 — Analytics Module
   ============================================================ */

function renderAnalytics() {
  const rev30  = Stats.totalRevenue(30);
  const exp30  = Stats.totalExpenses(30);
  const net30  = Stats.netProfit(30);
  const rev7   = Stats.totalRevenue(7);
  const exp7   = Stats.totalExpenses(7);
  const margin = rev30 > 0 ? (net30 / rev30 * 100).toFixed(1) : 0;
  const vehicles = DB.vehicles();

  const html = `
    <div class="page-header">
      <div class="page-header-left">
        <h1>Analyse & Performance</h1>
        <p class="page-subtitle">Indicateurs clés de rentabilité et performance de la flotte</p>
      </div>
      <div class="page-actions">
        <select class="filter-select" id="analytics-period" onchange="refreshAnalytics()">
          <option value="7">7 derniers jours</option>
          <option value="30" selected>30 derniers jours</option>
          <option value="90">3 derniers mois</option>
        </select>
        <button class="btn btn-outline btn-sm" onclick="exportAnalyticsPDF()"><i data-lucide="download"></i> Rapport</button>
      </div>
    </div>

    <!-- KPIs -->
    <div class="kpi-grid" style="margin-bottom:var(--space-5)">
      <div class="kpi-card accent">
        <div class="kpi-header">
          <div class="kpi-icon" style="background:var(--accent-light);color:var(--accent)"><i data-lucide="trending-up"></i></div>
          <div class="kpi-trend up"><i data-lucide="arrow-up"></i>+14%</div>
        </div>
        <div class="kpi-value">${fmtNum(Math.round(rev30/1000))}k</div>
        <div class="kpi-label">Chiffre d'affaires</div>
        <div class="kpi-sublabel">30 derniers jours</div>
      </div>
      <div class="kpi-card ${net30>=0?'success':'danger'}">
        <div class="kpi-header">
          <div class="kpi-icon" style="background:var(--success-light);color:var(--success)"><i data-lucide="wallet"></i></div>
          <div class="kpi-trend ${net30>=0?'up':'down'}">${margin}%</div>
        </div>
        <div class="kpi-value">${fmtNum(Math.round(net30/1000))}k</div>
        <div class="kpi-label">Bénéfice net</div>
        <div class="kpi-sublabel">Marge: ${margin}%</div>
      </div>
      <div class="kpi-card info">
        <div class="kpi-header">
          <div class="kpi-icon" style="background:var(--info-light);color:var(--info)"><i data-lucide="gauge"></i></div>
        </div>
        <div class="kpi-value">${vehicles.length > 0 ? fmtNum(Math.round(rev30/vehicles.filter(v=>v.status==='active').length/1000)) : 0}k</div>
        <div class="kpi-label">Rev. moyen/véhicule</div>
        <div class="kpi-sublabel">FCFA par véhicule actif</div>
      </div>
      <div class="kpi-card gold">
        <div class="kpi-header">
          <div class="kpi-icon" style="background:var(--gold-light,var(--warning-light));color:var(--gold,var(--warning))"><i data-lucide="percent"></i></div>
        </div>
        <div class="kpi-value">${margin}%</div>
        <div class="kpi-label">Taux de marge</div>
        <div class="kpi-sublabel">Net / CA total</div>
      </div>
      <div class="kpi-card secondary">
        <div class="kpi-header">
          <div class="kpi-icon" style="background:var(--secondary-light);color:var(--secondary)"><i data-lucide="route"></i></div>
        </div>
        <div class="kpi-value">${DB.trips().length}</div>
        <div class="kpi-label">Trajets réalisés</div>
        <div class="kpi-sublabel">Total enregistrés</div>
      </div>
      <div class="kpi-card warning">
        <div class="kpi-header">
          <div class="kpi-icon" style="background:var(--warning-light);color:var(--warning)"><i data-lucide="receipt"></i></div>
        </div>
        <div class="kpi-value">${fmtNum(Math.round(exp30/1000))}k</div>
        <div class="kpi-label">Total dépenses</div>
        <div class="kpi-sublabel">30 derniers jours</div>
      </div>
    </div>

    <!-- Charts Row 1 -->
    <div class="grid-12 mb-6">
      <div class="card col-8">
        <div class="card-header">
          <span class="card-title"><i data-lucide="bar-chart-3"></i> Évolution Revenus vs Dépenses</span>
        </div>
        <div class="card-body">
          <div class="chart-container" style="height:280px">
            <canvas id="analytics-revenue-chart"></canvas>
          </div>
        </div>
      </div>
      <div class="card col-4">
        <div class="card-header">
          <span class="card-title"><i data-lucide="pie-chart"></i> Répartition dépenses</span>
        </div>
        <div class="card-body" style="display:flex;flex-direction:column;align-items:center">
          <div class="chart-container" style="height:220px;width:220px">
            <canvas id="analytics-expense-pie"></canvas>
          </div>
        </div>
      </div>
    </div>

    <!-- Vehicle Performance Table -->
    <div class="card mb-6">
      <div class="card-header">
        <span class="card-title"><i data-lucide="table"></i> Performance par véhicule (30 jours)</span>
      </div>
      <div class="table-wrapper" style="border:none;border-radius:0">
        <table class="table">
          <thead>
            <tr>
              <th>Véhicule</th><th>Type</th><th>Conducteur</th>
              <th>Revenus</th><th>Dépenses</th><th>Bénéfice</th>
              <th>Rentabilité</th><th>Cible/j</th><th>Perf.</th>
            </tr>
          </thead>
          <tbody>
            ${vehicles.map(v => {
              const driver = v.driverId ? Stats.driverById(v.driverId) : null;
              const vRev = Stats.vehicleRevenue(v.id, 30);
              const vExp = Stats.vehicleExpenses(v.id, 30);
              const vNet = vRev - vExp;
              const rentab = vRev > 0 ? Math.round(vNet/vRev*100) : 0;
              const expectedRev = v.dailyTarget * 30;
              const perfPct = expectedRev > 0 ? Math.min(100, Math.round(vRev/expectedRev*100)) : 0;
              const typeEmoji = { bus:'🚌', minibus:'🚐', van:'🚙', truck:'🚛', other:'🚗' };
              return `<tr>
                <td>
                  <div style="display:flex;align-items:center;gap:8px">
                    <span style="font-size:1.2rem">${typeEmoji[v.type]||'🚗'}</span>
                    <div>
                      <div class="font-bold font-mono text-sm">${v.plate}</div>
                      <div class="text-xs text-muted">${v.brand} ${v.model}</div>
                    </div>
                  </div>
                </td>
                <td class="text-sm">${v.type}</td>
                <td class="text-sm">${driver?driver.firstName+' '+driver.lastName:'—'}</td>
                <td class="font-mono text-accent"><strong>${fmtCurrency(vRev)}</strong></td>
                <td class="font-mono text-danger">${fmtCurrency(vExp)}</td>
                <td class="font-mono ${vNet>=0?'text-success':'text-danger'}"><strong>${fmtCurrency(vNet)}</strong></td>
                <td>
                  <span class="badge ${rentab>=50?'badge-success':rentab>=20?'badge-warning':'badge-danger'}">${rentab}%</span>
                </td>
                <td class="font-mono text-sm">${fmtCurrency(v.dailyTarget)}</td>
                <td style="min-width:120px">
                  <div style="display:flex;align-items:center;gap:8px">
                    <div style="flex:1;height:6px;background:var(--bg-hover);border-radius:3px;overflow:hidden">
                      <div style="height:100%;width:${perfPct}%;background:${perfPct>=80?'var(--success)':perfPct>=50?'var(--warning)':'var(--danger)'};border-radius:3px;transition:width 0.5s ease"></div>
                    </div>
                    <span style="font-size:0.75rem;font-weight:700;min-width:32px">${perfPct}%</span>
                  </div>
                </td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Driver Performance -->
    <div class="card mb-6">
      <div class="card-header">
        <span class="card-title"><i data-lucide="users"></i> Classement conducteurs (par versements)</span>
      </div>
      <div class="card-body">
        <div class="grid-3">
          ${DB.drivers().map(d => {
            const dPayments = DB.payments().filter(p=>p.driverId===d.id && p.status==='paid');
            const total = dPayments.reduce((s,p)=>s+p.amount,0);
            const rate  = DB.payments().filter(p=>p.driverId===d.id).length > 0
              ? Math.round(dPayments.length/DB.payments().filter(p=>p.driverId===d.id).length*100) : 0;
            const v = d.vehicleId ? Stats.vehicleById(d.vehicleId) : null;
            return `<div class="card" style="border:1px solid var(--border-light);padding:16px">
              <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
                <div class="avatar" style="background:linear-gradient(135deg,var(--secondary),var(--accent))">${initials(d.firstName+' '+d.lastName)}</div>
                <div>
                  <div class="font-bold text-sm">${d.firstName} ${d.lastName}</div>
                  <div class="text-xs text-muted">${v?v.plate:'—'} · Note: ${d.rating}⭐</div>
                </div>
              </div>
              <div style="display:flex;gap:12px;margin-bottom:12px">
                <div class="mini-kpi" style="flex:1;padding:8px"><div class="mini-kpi-val text-accent" style="font-size:1rem">${fmtNum(Math.round(total/1000))}k</div><div class="mini-kpi-label">Total</div></div>
                <div class="mini-kpi" style="flex:1;padding:8px"><div class="mini-kpi-val" style="font-size:1rem">${rate}%</div><div class="mini-kpi-label">Ponctualité</div></div>
                <div class="mini-kpi" style="flex:1;padding:8px"><div class="mini-kpi-val" style="font-size:1rem">${dPayments.length}</div><div class="mini-kpi-label">Versements</div></div>
              </div>
              <div class="progress sm">
                <div class="progress-bar" style="width:${rate}%;background:${rate>=80?'var(--success)':rate>=50?'var(--warning)':'var(--danger)'}"></div>
              </div>
            </div>`;
          }).join('')}
        </div>
      </div>
    </div>

    <!-- Monthly Trend Chart -->
    <div class="card">
      <div class="card-header">
        <span class="card-title"><i data-lucide="line-chart"></i> Tendance mensuelle — Revenus</span>
      </div>
      <div class="card-body">
        <div class="chart-container" style="height:260px">
          <canvas id="analytics-trend-chart"></canvas>
        </div>
      </div>
    </div>
  `;

  document.getElementById('page-content').innerHTML = html;
  lucide.createIcons();

  setTimeout(() => {
    const dailyData = Stats.revenueByDay(30);
    renderAnalyticsRevenueChart(dailyData);
    renderAnalyticsExpensePie(Stats.expensesByCategory());
    renderAnalyticsTrendChart();
  }, 60);
}

function refreshAnalytics() {
  renderAnalytics();
}

function exportAnalyticsPDF() {
  showToast('info', 'Export', 'Rapport PDF disponible dans la version Pro');
}
